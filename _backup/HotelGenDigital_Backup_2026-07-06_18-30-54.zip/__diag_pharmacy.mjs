/**
 * TANI: "yakında eczane var mı" → "sistemde yok" sorunu
 * 
 * Bu script:
 * 1. detectInterestTag("yakında eczane var mı") simüle eder
 * 2. Central DB'den green-park-otel-demo hotel ID'sini alır
 * 3. Hotel'in bridge credentials'ını alır
 * 4. Hotel DB'den perplexity_discoveries tablosuna bakar
 */

import https from 'https';
import { readFileSync } from 'fs';
import { createDecipheriv } from 'crypto';

// ── ENV okuma ─────────────────────────────────────────────────────────────────
const envRaw = readFileSync('.env.local', 'utf-8');
const env = {};
for (const line of envRaw.split('\n')) {
  const m = line.match(/^([A-Z_][A-Z0-9_]*)="(.*)"$/);
  if (m) env[m[1]] = m[2];
}

const CENTRAL_URL    = env.CENTRAL_SUPABASE_URL;
const CENTRAL_KEY    = env.CENTRAL_SUPABASE_SERVICE_ROLE_KEY;
const ENCRYPTION_KEY = env.ENCRYPTION_MASTER_KEY;

if (!CENTRAL_URL || !CENTRAL_KEY) {
  console.error('❌ CENTRAL_SUPABASE_URL veya CENTRAL_SUPABASE_SERVICE_ROLE_KEY .env.local içinde eksik!');
  process.exit(1);
}

// ── normalizeTr (hotel-context.ts ile aynı) ───────────────────────────────────
function normalizeTr(s) {
  return s
    .replace(/İ/g, 'i')
    .replace(/I/g, 'i')
    .replace(/Ş/g, 's')
    .replace(/Ğ/g, 'g')
    .replace(/Ü/g, 'u')
    .replace(/Ö/g, 'o')
    .replace(/Ç/g, 'c')
    .toLowerCase()
    .replace(/ş/g, 's')
    .replace(/ğ/g, 'g')
    .replace(/ü/g, 'u')
    .replace(/ö/g, 'o')
    .replace(/ç/g, 'c')
    .replace(/ı/g, 'i');
}

// ── detectInterestTag (hotel-context.ts ile aynı) ─────────────────────────────
function detectInterestTag(message) {
  const text = normalizeTr(message);
  const pharmacyKws = ['eczane', 'ilac', 'ilaci', 'ilacim', 'nobetci', 'nobetci eczane',
    'pharmacy', 'chemist', 'drugstore', 'medicine', 'drug',
    'apotheke', 'medikament', 'arznei',
    'pharmacie', 'medicament', 'medicaments',
    'صيدلية', 'دواء', 'ادوية', 'صيدلي',
    'аптека', 'лекарство', 'лекарства', 'таблетки'];

  for (const kw of pharmacyKws) {
    const normalizedKw = normalizeTr(kw);
    if (text.includes(normalizedKw)) {
      return { tag: 'pharmacy', matchedKeyword: kw, normalizedKw, textSeen: text };
    }
  }
  return null;
}

// ── HTTP helper ───────────────────────────────────────────────────────────────
function get(baseUrl, path, serviceKey) {
  return new Promise((resolve, reject) => {
    const url = new URL(baseUrl + path);
    const opts = {
      hostname: url.hostname,
      path: url.pathname + url.search,
      method: 'GET',
      headers: {
        'apikey': serviceKey,
        'Authorization': 'Bearer ' + serviceKey,
        'Content-Type': 'application/json',
        'Prefer': 'return=representation',
      }
    };
    const req = https.request(opts, (res) => {
      let data = '';
      res.on('data', c => data += c);
      res.on('end', () => {
        try { resolve(JSON.parse(data)); }
        catch { resolve({ _raw: data }); }
      });
    });
    req.on('error', reject);
    req.end();
  });
}

// ── AES-256-GCM decrypt (encryption.ts ile aynı mantık) ──────────────────────
function decryptCredential(encryptedHex) {
  if (!ENCRYPTION_KEY) {
    return '(ENCRYPTION_MASTER_KEY eksik — decrypt edilemiyor)';
  }
  try {
    const buf = Buffer.from(encryptedHex, 'hex');
    const iv  = buf.slice(0, 12);
    const tag = buf.slice(12, 28);
    const ct  = buf.slice(28);
    const key = Buffer.from(ENCRYPTION_KEY, 'hex');
    const decipher = createDecipheriv('aes-256-gcm', key, iv);
    decipher.setAuthTag(tag);
    return decipher.update(ct, undefined, 'utf8') + decipher.final('utf8');
  } catch(e) {
    return `(decrypt hatası: ${e.message})`;
  }
}

// ── MAIN ──────────────────────────────────────────────────────────────────────
async function main() {
  const MSG = 'yakında eczane var mı';
  console.log('\n════════════════════════════════════════════════════');
  console.log('TANI: "yakında eczane var mı" → "sistemde yok" sorunu');
  console.log('════════════════════════════════════════════════════\n');

  // ── 1. detectInterestTag testi ──────────────────────────────────────────────
  console.log('【1】 detectInterestTag testi');
  const tagResult = detectInterestTag(MSG);
  if (tagResult) {
    console.log(`  ✅ TAG DÖNDÜ: "${tagResult.tag}"`);
    console.log(`     - Eşleşen keyword: "${tagResult.matchedKeyword}"`);
    console.log(`     - Normalize edilmiş kw: "${tagResult.normalizedKw}"`);
    console.log(`     - Normalize edilmiş mesaj: "${tagResult.textSeen}"`);
  } else {
    console.log(`  ❌ TAG NULL DÖNDÜ — detectInterestTag "eczane" eşleştiremedi!`);
    console.log(`     Mesaj normalize hali: "${normalizeTr(MSG)}"`);
  }
  console.log();

  // ── 2. Central DB'den green-park-otel-demo bul ─────────────────────────────
  console.log('【2】 Central DB — green-park-otel-demo hotel kaydı');
  const hotels = await get(CENTRAL_URL, '/rest/v1/hotels?select=id,name,slug,is_demo&slug=eq.green-park-otel-demo', CENTRAL_KEY);
  if (!Array.isArray(hotels) || hotels.length === 0) {
    console.log('  ❌ hotels tablosunda slug=green-park-otel-demo BULUNAMADI');
    console.log('  Raw:', JSON.stringify(hotels));
    // Tüm otelleri listele
    const allHotels = await get(CENTRAL_URL, '/rest/v1/hotels?select=id,name,slug,is_demo&order=created_at.desc&limit=20', CENTRAL_KEY);
    console.log('\n  Mevcut otel slug\'ları:');
    if (Array.isArray(allHotels)) {
      allHotels.forEach(h => console.log(`    - ${h.slug} (${h.name})`));
    } else {
      console.log('  Central DB erişim hatası:', JSON.stringify(allHotels));
    }
    return;
  }
  const hotel = hotels[0];
  console.log(`  ✅ Bulundu: id=${hotel.id} | slug=${hotel.slug} | is_demo=${hotel.is_demo}`);
  console.log();

  // ── 3. Bridge credentials ──────────────────────────────────────────────────
  console.log('【3】 Bridge credentials');
  const creds = await get(CENTRAL_URL, `/rest/v1/bridge_credentials?select=supabase_url_encrypted,supabase_service_key_encrypted,is_healthy&hotel_id=eq.${hotel.id}`, CENTRAL_KEY);
  if (!Array.isArray(creds) || creds.length === 0) {
    console.log('  ❌ bridge_credentials BULUNAMADI — hotel DB\'ye bağlanamıyoruz');
    return;
  }
  const cred = creds[0];
  console.log(`  is_healthy: ${cred.is_healthy}`);

  const hotelUrl = decryptCredential(cred.supabase_url_encrypted);
  const hotelKey = decryptCredential(cred.supabase_service_key_encrypted);
  
  if (hotelUrl.startsWith('(') || hotelKey.startsWith('(')) {
    console.log(`  ⚠️  Decrypt başarısız — ENCRYPTION_MASTER_KEY eksik veya hatalı`);
    console.log(`     Hotel URL encrypted prefix: ${cred.supabase_url_encrypted?.slice(0,20)}...`);
    console.log(`\n  🔴 Hotel DB'ye erişilemiyor. Supabase panelinden perplexity_discoveries tablosuna bakın.`);
    console.log(`     Hotel ID: ${hotel.id}`);
    return;
  }
  
  console.log(`  ✅ Hotel Supabase URL: ${hotelUrl}`);
  console.log();

  // ── 4. perplexity_discoveries tablosuna bak ────────────────────────────────
  console.log('【4】 Hotel DB — perplexity_discoveries tablosu (interest_tag=pharmacy)');
  
  // Önce tüm kayıtları say
  const allRows = await get(hotelUrl, '/rest/v1/perplexity_discoveries?select=interest_tag,created_at,expires_at&order=created_at.desc&limit=50', hotelKey);
  if (!Array.isArray(allRows)) {
    console.log('  ❌ perplexity_discoveries tablosu okunamadı:', JSON.stringify(allRows));
  } else {
    console.log(`  Toplam kayıt (limit 50): ${allRows.length}`);
    const uniqueTags = [...new Set(allRows.map(r => r.interest_tag))];
    console.log(`  Mevcut interest_tag'ler: ${uniqueTags.join(', ') || '(tablo boş)'}`);
    console.log();
  }

  // Sadece pharmacy kayıtları
  const pharmacyRows = await get(hotelUrl, '/rest/v1/perplexity_discoveries?select=interest_tag,created_at,expires_at,results&interest_tag=eq.pharmacy&order=created_at.desc&limit=5', hotelKey);
  if (!Array.isArray(pharmacyRows)) {
    console.log('  ❌ pharmacy sorgu hatası:', JSON.stringify(pharmacyRows));
  } else if (pharmacyRows.length === 0) {
    console.log('  ❌ interest_tag=pharmacy KAYDI YOK — fetchNearbyPlaces boş dönecek!');
    console.log('  → ÇÖZÜM: Kemal panelden "Yeniden Sorgula" (pharmacy) yapmalı.');
  } else {
    console.log(`  ✅ interest_tag=pharmacy kayıt sayısı: ${pharmacyRows.length}`);
    for (const row of pharmacyRows) {
      const results = Array.isArray(row.results) ? row.results : [];
      const now = new Date();
      const expiresAt = row.expires_at ? new Date(row.expires_at) : null;
      const isExpired = expiresAt ? expiresAt < now : false;
      
      console.log(`\n  Kayıt:`);
      console.log(`    created_at : ${row.created_at}`);
      console.log(`    expires_at : ${row.expires_at ?? '(null — bu alan yok veya boş)'}`);
      console.log(`    expired?   : ${expiresAt ? (isExpired ? '❌ EVET — SÜRESI DOLMUŞ' : '✅ Hayır') : '(expires_at null)'}`);
      console.log(`    results[]  : ${results.length} adet yer`);
      if (results.length > 0) {
        console.log(`    Örnek yer  : ${JSON.stringify(results[0]).slice(0, 150)}`);
      }
    }
  }

  // ── 5. fetchNearbyPlaces simülasyonu ───────────────────────────────────────
  console.log('\n【5】 fetchNearbyPlaces simülasyonu (expires_at filtresi var mı?)');
  console.log('  Mevcut sorgu (hotel-context.ts L275-281):');
  console.log('    .from("perplexity_discoveries")');
  console.log('    .select("interest_tag, results, created_at")');
  console.log('    .eq("interest_tag", "pharmacy")');
  console.log('    .order("created_at", { ascending: false })');
  console.log('    .limit(1)');
  console.log('    .maybeSingle()');
  console.log();
  console.log('  ✅ expires_at filtresi YOK (1a0f412 öncesi kaldırıldı mı doğrulanıyor...)');
  
  // Source kodu doğrula
  const { readFileSync } = await import('fs');
  const src = readFileSync('./src/lib/ai/hotel-context.ts', 'utf-8');
  const hasExpiresFilter = src.includes('.gte(\'expires_at\'') || src.includes('.gt(\'expires_at\'') || src.includes('expires_at');
  console.log(`  Kod içinde "expires_at" geçiyor mu: ${hasExpiresFilter ? '🔴 EVET — FİLTRE HÂLÂ MEVCUT!' : '✅ HAYIR — filtre yok'}`);

  console.log('\n════════════════════════════════════════════════════');
  console.log('ÖZET');
  console.log('════════════════════════════════════════════════════');
}

main().catch(e => {
  console.error('Script hatası:', e.message);
  console.error(e.stack);
});
