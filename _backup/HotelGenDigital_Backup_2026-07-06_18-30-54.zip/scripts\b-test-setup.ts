/**
 * b-test-setup.ts — Kademeli doğrulama tonu (soft/warn) için CANLI test zemini temizler.
 * Route logic'ine DOKUNMAZ. Çalıştır: npx tsx scripts/b-test-setup.ts
 *
 * Webhook route'unun KULLANDIĞI gerçek tenant-client zinciri (diag-recognize.ts ile aynı kalıp):
 *   getHotelBySlug(slug) -> hotel.id  (@/lib/tenant/get-hotel-by-slug)
 *   getHotelClient(hotel.id) -> SupabaseClient  (@/lib/tenant/get-hotel-client)
 */

import * as dotenv from 'dotenv';
import * as path from 'path';
import * as fs from 'fs';

// .env.local yükle (repo konvansiyonu — diag-recognize.ts ile aynı)
const envPath = path.resolve(process.cwd(), '.env.local');
if (fs.existsSync(envPath)) {
  dotenv.config({ path: envPath });
} else {
  dotenv.config();
}

import { getHotelBySlug } from '../src/lib/tenant/get-hotel-by-slug';
import { getHotelClient } from '../src/lib/tenant/get-hotel-client';

const SLUG = 'regnum-hotels-belek';
const GUEST_ID = '5f3d14af-6102-4c4c-826c-1ae4ecdc65a0';
const CHAT_ID = '758605940';

async function main() {
  const hotel = await getHotelBySlug(SLUG);
  if (!hotel) { console.error('HOTEL_NOT_FOUND'); process.exit(1); }
  const supa = await getHotelClient(hotel.id);
  if (!supa) { console.error('CLIENT_NULL (bridge decrypt başarısız)'); process.exit(1); }
  console.log('HOTEL =', hotel.id, 'CONNECTED_URL =', (supa as any).supabaseUrl ?? 'bilinmiyor');

  // a) inhouse_guests_v2: telegram_id damgasını kaldır
  const aRes = await supa
    .from('inhouse_guests_v2')
    .update({ telegram_id: null })
    .eq('id', GUEST_ID)
    .select('id, telegram_id');
  if (aRes.error) { console.error('STEP_A_ERR', aRes.error.message); process.exit(1); }
  console.log('STEP A (telegram_id=NULL) ->', JSON.stringify(aRes.data));

  // b) conversations: doğrulama state'ini sıfırla
  const bRes = await supa
    .from('conversations')
    .update({
      verification_attempts: 0,
      verified_inhouse_guest_id: null,
      verified_at: null,
      verification_pending_intent: null,
      pending_request_text: null,
    })
    .eq('telegram_chat_id', CHAT_ID)
    .select('id, telegram_chat_id, verification_attempts');
  if (bRes.error) { console.error('STEP_B_ERR', bRes.error.message); process.exit(1); }
  console.log('STEP B (conv reset) ->', JSON.stringify(bRes.data));

  // c) bot_messages: bu conversation_id'lerin tüm satırlarını sil
  const convIds = (bRes.data ?? []).map((r: any) => r.id as string);
  if (convIds.length > 0) {
    const cRes = await supa
      .from('bot_messages')
      .delete()
      .in('conversation_id', convIds)
      .select('id');
    if (cRes.error) { console.error('STEP_C_ERR', cRes.error.message); process.exit(1); }
    console.log('STEP C (bot_messages silindi) ->', (cRes.data ?? []).length, 'satır');
  } else {
    console.log('STEP C atlandı — eşleşen conversation yok');
  }

  // d)
  console.log('B-SETUP DONE');
}

main().catch((e) => { console.error('B_SETUP_ERR', e); process.exit(1); });
