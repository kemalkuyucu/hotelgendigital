#!/usr/bin/env pwsh

$SECRET = "ee7f3ad0a5e469c5fccae35076767a5e96ec33f08d9a7e80ea4c982062d9b70d"
$URL = "https://hotelgen-v2.vercel.app/api/webhooks/telegram/green-park-otel-demo"
$SUPABASE_URL = "https://rvsyvegfeywzqbqljlij.supabase.co"
$SUPABASE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJ2c3l2ZWdmZXl3enFicWxqbGlqIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc3Nzk3MzQ2OCwiZXhwIjoyMDkzNTQ5NDY4fQ.T1NtIugkuxcX0sLcw3LVDavJHLhdXzjwR4FO2oDiEio"

function Invoke-Webhook($body) {
    $response = Invoke-RestMethod -Uri $URL -Method POST `
        -ContentType "application/json" `
        -Headers @{ "x-telegram-bot-api-secret-token" = $SECRET } `
        -Body ($body | ConvertTo-Json -Depth 10) `
        -ErrorAction SilentlyContinue
    return $response
}

function Get-DbState($table, $filters) {
    $uri = "$SUPABASE_URL/rest/v1/$table" + $filters
    $result = Invoke-RestMethod -Uri $uri -Method GET `
        -Headers @{ "apikey" = $SUPABASE_KEY; "Authorization" = "Bearer $SUPABASE_KEY" }
    return $result
}

# ============================================================
# SENARYO A - DOGRULANMAMIS KULLANICI
# Telegram ID: 9999001 (yeni, hic dogrulanmamis)
# ============================================================
Write-Host "`n========================================" -ForegroundColor Cyan
Write-Host "SENARYO A - DOGRULANMAMIS KULLANICI" -ForegroundColor Cyan
Write-Host "Telegram ID: 9999001" -ForegroundColor Cyan
Write-Host "Mesaj: 'yakinda eczane var mi'" -ForegroundColor Cyan
Write-Host "========================================`n" -ForegroundColor Cyan

# Onceki forwarded_messages sayisini al
$fwdBefore_A = Get-DbState "forwarded_messages" "?select=id&order=created_at.desc&limit=100"
$fwdCountBefore_A = $fwdBefore_A.Count
Write-Host "forwarded_messages onceki sayi: $fwdCountBefore_A" -ForegroundColor Yellow

# sla_events onceki sayisi
$slaBefore_A = Get-DbState "sla_events" "?select=id&order=created_at.desc&limit=100"
$slaCountBefore_A = $slaBefore_A.Count
Write-Host "sla_events onceki sayi: $slaCountBefore_A" -ForegroundColor Yellow

$bodyA = @{
    update_id = 200001
    message = @{
        message_id = 1
        from = @{ id = 9999001; is_bot = $false; first_name = "TestA"; language_code = "tr" }
        chat = @{ id = 9999001; type = "private" }
        date = 1748592000
        text = "yakinda eczane var mi"
    }
}

Write-Host "Webhook gonderiliyor..." -ForegroundColor Green
$resultA = Invoke-Webhook $bodyA
Write-Host "Webhook yaniti: $($resultA | ConvertTo-Json)" -ForegroundColor Green

Start-Sleep -Seconds 5

# Sonrasi
$fwdAfter_A = Get-DbState "forwarded_messages" "?select=id,department_code,created_at,target_type&order=created_at.desc&limit=5"
$slaAfter_A = Get-DbState "sla_events" "?select=id,department_code,request_text,created_at&order=created_at.desc&limit=5"

Write-Host "`n--- SENARYO A SONUCLARI ---" -ForegroundColor Cyan
Write-Host "forwarded_messages oncesi: $fwdCountBefore_A" -ForegroundColor White
Write-Host "forwarded_messages sonrasi: $($fwdAfter_A.Count)" -ForegroundColor White
$newFwdA = $fwdAfter_A.Count - $fwdCountBefore_A
Write-Host "YENI forwarded_messages: $newFwdA" -ForegroundColor $(if ($newFwdA -gt 0) { "Red" } else { "Green" })

Write-Host "sla_events oncesi: $slaCountBefore_A" -ForegroundColor White
Write-Host "sla_events sonrasi: $($slaAfter_A.Count)" -ForegroundColor White
$newSlaA = $slaAfter_A.Count - $slaCountBefore_A
Write-Host "YENI sla_events: $newSlaA" -ForegroundColor $(if ($newSlaA -gt 0) { "Red" } else { "Green" })

if ($fwdAfter_A.Count -gt 0) {
    Write-Host "En son forwarded_message: $($fwdAfter_A[0] | ConvertTo-Json)" -ForegroundColor White
}
if ($slaAfter_A.Count -gt 0) {
    Write-Host "En son sla_event: $($slaAfter_A[0] | ConvertTo-Json)" -ForegroundColor White
}

Write-Host "`nSenaryo A tamamlandi. FORWARD VAR MI: $($newSlaA -gt 0 -or $newFwdA -gt 0)" -ForegroundColor $(if ($newSlaA -gt 0 -or $newFwdA -gt 0) { "Red" } else { "Green" })

Start-Sleep -Seconds 3

# ============================================================
# SENARYO B - DOGRULANMIS KULLANICI (Ozgur Ozen, oda 102)
# Telegram ID: 758605940
# ============================================================
Write-Host "`n========================================" -ForegroundColor Magenta
Write-Host "SENARYO B - DOGRULANMIS KULLANICI" -ForegroundColor Magenta
Write-Host "Telegram ID: 758605940 (Ozgur Ozen)" -ForegroundColor Magenta
Write-Host "ADIM 1: 'klima calismiyor 102 Ozgur Ozen'" -ForegroundColor Magenta
Write-Host "========================================`n" -ForegroundColor Magenta

# Adim 1: Dogrulama mesaji gonder
$bodyB1 = @{
    update_id = 200010
    message = @{
        message_id = 10
        from = @{ id = 758605940; is_bot = $false; first_name = "Ozgur"; language_code = "tr" }
        chat = @{ id = 758605940; type = "private" }
        date = 1748592100
        text = "klima calismiyor 102 Ozgur Ozen"
    }
}

Write-Host "B Adim1 gonderiliyor (dogrulama)..." -ForegroundColor Green
$resultB1 = Invoke-Webhook $bodyB1
Write-Host "B Adim1 yaniti: $($resultB1 | ConvertTo-Json)" -ForegroundColor Green

Start-Sleep -Seconds 8

# Dogrulanmis mi kontrol et
$convB = Get-DbState "conversations" "?select=id,verified_inhouse_guest_id,verified_at&order=created_at.desc&limit=5"
Write-Host "Conversations durumu:" -ForegroundColor Yellow
$convB | ForEach-Object { Write-Host "  id=$($_.id) verified_guest=$($_.verified_inhouse_guest_id) verified_at=$($_.verified_at)" }

# Forward sayilarini kaydet
$fwdBefore_B = Get-DbState "forwarded_messages" "?select=id&order=created_at.desc&limit=100"
$fwdCountBefore_B = $fwdBefore_B.Count
$slaBefore_B = Get-DbState "sla_events" "?select=id&order=created_at.desc&limit=100"
$slaCountBefore_B = $slaBefore_B.Count

Write-Host "`n--- Adim 1 sonrasi sayilar ---" -ForegroundColor Yellow
Write-Host "forwarded_messages: $fwdCountBefore_B" -ForegroundColor White
Write-Host "sla_events: $slaCountBefore_B" -ForegroundColor White

Start-Sleep -Seconds 3

# Adim 2: Bilgi sorusu gonder (dogrulanmis kullanici)
Write-Host "`n--- SENARYO B ADIM 2: 'yakinda eczane var mi' ---" -ForegroundColor Magenta
$bodyB2 = @{
    update_id = 200011
    message = @{
        message_id = 11
        from = @{ id = 758605940; is_bot = $false; first_name = "Ozgur"; language_code = "tr" }
        chat = @{ id = 758605940; type = "private" }
        date = 1748592200
        text = "yakinda eczane var mi"
    }
}

Write-Host "B Adim2 gonderiliyor (bilgi sorusu - eczane)..." -ForegroundColor Green
$resultB2 = Invoke-Webhook $bodyB2
Write-Host "B Adim2 yaniti: $($resultB2 | ConvertTo-Json)" -ForegroundColor Green

Start-Sleep -Seconds 8

# Son durumu kontrol et
$fwdAfter_B = Get-DbState "forwarded_messages" "?select=id,department_code,created_at,target_type&order=created_at.desc&limit=5"
$slaAfter_B = Get-DbState "sla_events" "?select=id,department_code,request_text,created_at,room_number,guest_full_name&order=created_at.desc&limit=5"

Write-Host "`n--- SENARYO B ADIM2 SONUCLARI ---" -ForegroundColor Magenta
Write-Host "forwarded_messages oncesi (Adim2): $fwdCountBefore_B" -ForegroundColor White
Write-Host "forwarded_messages sonrasi: $($fwdAfter_B.Count)" -ForegroundColor White
$newFwdB = $fwdAfter_B.Count - $fwdCountBefore_B
Write-Host "YENI forwarded_messages (Adim2): $newFwdB" -ForegroundColor $(if ($newFwdB -gt 0) { "Red" } else { "Green" })

Write-Host "sla_events oncesi (Adim2): $slaCountBefore_B" -ForegroundColor White
Write-Host "sla_events sonrasi: $($slaAfter_B.Count)" -ForegroundColor White
$newSlaB = $slaAfter_B.Count - $slaCountBefore_B
Write-Host "YENI sla_events (Adim2): $newSlaB" -ForegroundColor $(if ($newSlaB -gt 0) { "Red" } else { "Green" })

if ($fwdAfter_B.Count -gt 0) {
    Write-Host "En son forwarded_messages:" -ForegroundColor White
    $fwdAfter_B | Select-Object -First 3 | ForEach-Object { Write-Host "  $($_ | ConvertTo-Json -Compress)" }
}
if ($slaAfter_B.Count -gt 0) {
    Write-Host "En son sla_events:" -ForegroundColor White
    $slaAfter_B | Select-Object -First 3 | ForEach-Object { Write-Host "  $($_ | ConvertTo-Json -Compress)" }
}

Write-Host "`nSenaryo B ADIM2 FORWARD VAR MI: $($newSlaB -gt 0 -or $newFwdB -gt 0)" -ForegroundColor $(if ($newSlaB -gt 0 -or $newFwdB -gt 0) { "Red" } else { "Green" })

# ============================================================
# OZET
# ============================================================
Write-Host "`n`n========================================" -ForegroundColor Yellow
Write-Host "KARSILASTIRMA OZETI" -ForegroundColor Yellow
Write-Host "========================================" -ForegroundColor Yellow
Write-Host "Senaryo A (dogrulanmamis) forward: $($newSlaA -gt 0 -or $newFwdA -gt 0)" -ForegroundColor White
Write-Host "Senaryo B Adim2 (dogrulanmis) forward: $($newSlaB -gt 0 -or $newFwdB -gt 0)" -ForegroundColor White

if (-not ($newSlaA -gt 0 -or $newFwdA -gt 0) -and ($newSlaB -gt 0 -or $newFwdB -gt 0)) {
    Write-Host "`nHIPOTEZ DOGRULANDI! A'da forward yok, B'de forward VAR." -ForegroundColor Red
    Write-Host "Dogrulanmis misafir bilgi sorusu forward bug'i kanItlandi." -ForegroundColor Red
} elseif (-not ($newSlaA -gt 0 -or $newFwdA -gt 0) -and -not ($newSlaB -gt 0 -or $newFwdB -gt 0)) {
    Write-Host "`nHer iki senaryoda da forward YOK — hipotez REDDEDILDi veya gecici fix calisti." -ForegroundColor Green
} elseif (($newSlaA -gt 0 -or $newFwdA -gt 0) -and ($newSlaB -gt 0 -or $newFwdB -gt 0)) {
    Write-Host "`nHer iki senaryoda da forward VAR — genel bir forward bug var, sadece dogrulama ile ilgili degil." -ForegroundColor Red
} else {
    Write-Host "`nBEKLENMEDIK DURUM: A'da forward var, B'de yok. Tekrar kontrol et." -ForegroundColor Yellow
}
