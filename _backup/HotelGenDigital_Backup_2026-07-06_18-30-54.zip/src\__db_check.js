const { Pool } = require('pg');
const pool = new Pool({ connectionString: process.env.DATABASE_URL });

async function main() {
  const r1 = await pool.query(`
    SELECT allergen_asked, allergen_pending, verification_pending_intent, verified_at
    FROM conversations
    ORDER BY updated_at DESC
    LIMIT 1
  `);
  console.log('=== conversations (en son güncellenen) ===');
  console.table(r1.rows);

  const r2 = await pool.query(`
    SELECT status, allergen_text, asked_at, platform_user_id
    FROM guest_allergens
    ORDER BY created_at DESC
    LIMIT 5
  `);
  console.log('=== guest_allergens (en son 5 kayıt) ===');
  console.table(r2.rows);

  await pool.end();
}

main().catch(e => { console.error(e.message); pool.end(); });
