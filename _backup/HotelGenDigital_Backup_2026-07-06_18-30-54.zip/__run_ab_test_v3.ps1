#!/usr/bin/env pwsh

$SUPABASE_URL = "https://rvsyvegfeywzqbqljlij.supabase.co"
$SUPABASE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJ2c3l2ZWdmZXl3enFicWxqbGlqIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc3Nzk3MzQ2OCwiZXhwIjoyMDkzNTQ5NDY4fQ.T1NtIugkuxcX0sLcw3LVDavJHLhdXzjwR4FO2oDiEio"
$SECRET = "ee7f3ad0a5e469c5fccae35076767a5e96ec33f08d9a7e80ea4c982062d9b70d"
$URL = "https://hotelgen-v2.vercel.app/api/webhooks/telegram/green-park-otel-demo"

$OZGUR_V2_ID = "5b047515-419c-4105-896f-aa23d56c29da"
$OZGUR_CONV_ID = "0b389003-c215-4c40-9226-be50eaafc668"
$OZGUR_TG_ID = 758605940

$supaHeaders = @{
    "apikey"        = $SUPABASE_KEY
    "Authorization" = "Bearer $SUPABASE_KEY"
    "Content-Type"  = "application/json"
}

function Invoke-Webhook($body) {
    $json = $body | ConvertTo-Json -Depth 10 -Compress
    $response = Invoke-RestMethod -Uri $URL -Method POST `
        -ContentType "application/json" `
        -Headers @{ "x-telegram-bot-api-secret-token" = $SECRET } `
        -Body $json
    return $response
}

function Get-SlaCount() {
    $r = Invoke-RestMethod -Uri "$SUPABASE_URL/rest/v1/sla_events?select=id,department_code,request_text,room_number,created_at&order=created_at.desc" -Headers $supaHeaders
    return $r
}

# ==========================================================
# STEP 1: Ozgur conversation'ina verified_inhouse_guest_id ATA
# ==========================================================
Write-Host "=== OZGUR CONVERSATION VERIFIED DURUMUNA GETIRILIYOR ===" -ForegroundColor Yellow

$patchBody = @{
    verified_inhouse_guest_id  = $OZGUR_V2_ID
    verified_at                = "2026-05-30T07:00:00.000Z"
    verification_pending_intent = $null
    verification_attempts      = 0
    pending_request_text       = "klima calismiyor"
}

$patchJson = $patchBody | ConvertTo-Json -Compress
Write-Host "PATCH JSON: $patchJson"

$patchHeaders = $supaHeaders.Clone()
$patchHeaders["Prefer"] = "return=representation"

try {
    $patchResult = Invoke-RestMethod -Uri "$SUPABASE_URL/rest/v1/conversations?id=eq.$OZGUR_CONV_ID" `
        -Method PATCH `
        -Headers $patchHeaders `
        -Body $patchJson
    Write-Host "PATCH basarili: $($patchResult | ConvertTo-Json -Compress)" -ForegroundColor Green
} catch {
    Write-Host "PATCH hatasi: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host "Status: $($_.Exception.Response.StatusCode)" -ForegroundColor Red
    
    # StatusCode 409 = RLS hatasi - force try without prefer header
    Write-Host "Prefer header olmadan deneniyor..." -ForegroundColor Yellow
    $patchHeaders2 = @{
        "apikey"        = $SUPABASE_KEY
        "Authorization" = "Bearer $SUPABASE_KEY"
        "Content-Type"  = "application/json"
    }
    try {
        $patchResult2 = Invoke-RestMethod -Uri "$SUPABASE_URL/rest/v1/conversations?id=eq.$OZGUR_CONV_ID" `
            -Method PATCH `
            -Headers $patchHeaders2 `
            -Body $patchJson
        Write-Host "PATCH2 basarili (no-prefer)" -ForegroundColor Green
    } catch {
        Write-Host "PATCH2 de basarisiz: $($_.Exception.Message)" -ForegroundColor Red
    }
}

# Verify
Start-Sleep -Seconds 2
$convCheck = Invoke-RestMethod -Uri "$SUPABASE_URL/rest/v1/conversations?id=eq.$OZGUR_CONV_ID&select=id,verified_inhouse_guest_id,verified_at" -Headers $supaHeaders
Write-Host "Conversation durumu sonra: verified=$($convCheck.verified_inhouse_guest_id)" -ForegroundColor Cyan

# ==========================================================
# SENARYO A: Dogrulanmamis kullanici (9999001)
# ==========================================================
Write-Host "`n========================================" -ForegroundColor Cyan
Write-Host "SENARYO A: DOGRULANMAMIS (9999001)" -ForegroundColor Cyan
Write-Host "Mesaj: 'yakinda eczane var mi'" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan

$slaBefore_A = Get-SlaCount
$countBefore_A = $slaBefore_A.Count
Write-Host "sla_events oncesi: $countBefore_A" -ForegroundColor Yellow

$bodyA = @{
    update_id = 400001
    message = @{
        message_id = 201
        from = @{ id = 9999001; is_bot = $false; first_name = "TestA"; language_code = "tr" }
        chat = @{ id = 9999001; type = "private" }
        date = [int][DateTimeOffset]::UtcNow.ToUnixTimeSeconds()
        text = "yakinda eczane var mi"
    }
}

$resultA = Invoke-Webhook $bodyA
Write-Host "Webhook A yaniti: $($resultA | ConvertTo-Json -Compress)" -ForegroundColor Green

Start-Sleep -Seconds 10

$slaAfter_A = Get-SlaCount
$countAfter_A = $slaAfter_A.Count
$newA = $countAfter_A - $countBefore_A
Write-Host "sla_events sonrasi: $countAfter_A (delta: +$newA)" -ForegroundColor $(if ($newA -gt 0) { "Red" } else { "Green" })
if ($newA -gt 0) {
    Write-Host "YENi SLA: $($slaAfter_A | Select-Object -First 1 | ConvertTo-Json -Compress)" -ForegroundColor Red
}

# ==========================================================
# SENARYO B: Dogrulanmis kullanici (Ozgur, 758605940)
# ==========================================================
Write-Host "`n========================================" -ForegroundColor Magenta
Write-Host "SENARYO B: DOGRULANMIS (Ozgur, 758605940)" -ForegroundColor Magenta

# Ozgur conversation'inin verified durumunu kontrol et
$convB = Invoke-RestMethod -Uri "$SUPABASE_URL/rest/v1/conversations?id=eq.$OZGUR_CONV_ID&select=id,verified_inhouse_guest_id,verified_at" -Headers $supaHeaders
Write-Host "Ozgur conv: verified=$($convB.verified_inhouse_guest_id)" -ForegroundColor Cyan

if (-not $convB.verified_inhouse_guest_id) {
    Write-Host "WARNING: Ozgur hala dogrulanmamis! PATCH basarisiz oldu." -ForegroundColor Red
    Write-Host "Senaryo B ATLIYOR - gecerli sonuc yok." -ForegroundColor Red
} else {
    Write-Host "Ozgur dogrulanmis durumda. Mesaj: 'yakinda eczane var mi'" -ForegroundColor Magenta
    Write-Host "========================================" -ForegroundColor Magenta

    $slaBefore_B = Get-SlaCount
    $countBefore_B = $slaBefore_B.Count
    Write-Host "sla_events oncesi (B): $countBefore_B" -ForegroundColor Yellow

    $bodyB = @{
        update_id = 400010
        message = @{
            message_id = 210
            from = @{ id = $OZGUR_TG_ID; is_bot = $false; first_name = "Ozgur"; language_code = "tr" }
            chat = @{ id = $OZGUR_TG_ID; type = "private" }
            date = [int][DateTimeOffset]::UtcNow.ToUnixTimeSeconds()
            text = "yakinda eczane var mi"
        }
    }

    $resultB = Invoke-Webhook $bodyB
    Write-Host "Webhook B yaniti: $($resultB | ConvertTo-Json -Compress)" -ForegroundColor Green

    Start-Sleep -Seconds 10

    $slaAfter_B = Get-SlaCount
    $countAfter_B = $slaAfter_B.Count
    $newB = $countAfter_B - $countBefore_B
    Write-Host "sla_events sonrasi (B): $countAfter_B (delta: +$newB)" -ForegroundColor $(if ($newB -gt 0) { "Red" } else { "Green" })
    if ($newB -gt 0) {
        Write-Host "YENi SLA (B): $($slaAfter_B | Select-Object -First 1 | ConvertTo-Json -Compress)" -ForegroundColor Red
    }

    Write-Host "`n=== FINAL SONUC ===" -ForegroundColor Yellow
    Write-Host "Senaryo A (dogrulanmamis): +$newA forward" -ForegroundColor White
    Write-Host "Senaryo B (dogrulanmis): +$newB forward" -ForegroundColor White
    
    if ($newA -eq 0 -and $newB -gt 0) {
        Write-Host "*** HIPOTEZ KANITLANDI: persistentVerifiedGuest bug mevcut! ***" -ForegroundColor Red
    } elseif ($newA -eq 0 -and $newB -eq 0) {
        Write-Host "Her iki durumda da forward yok - fix calistiyor." -ForegroundColor Green
    } else {
        Write-Host "Beklenmedik sonuc. Manuel inceleme gerekli." -ForegroundColor Yellow
    }
}
