/**
 * ALERJEN MODÜL 4 — Teşhis Sorguları
 * Demo Hotel tenant DB: rvsyvegfeywzqbqljlij.supabase.co
 */
const https = require('https');

const SUPABASE_URL = 'https://rvsyvegfeywzqbqljlij.supabase.co';
const SERVICE_KEY  = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJ2c3l2ZWdmZXl3enFicWxqbGlqIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc3Nzk3MzQ2OCwiZXhwIjoyMDkzNTQ5NDY4fQ.T1NtIugkuxcX0sLcw3LVDavJHLhdXzjwR4FO2oDiEio';

function req(path) {
  return new Promise((resolve, reject) => {
    const url = new URL(SUPABASE_URL + path);
    const opts = {
      hostname: url.hostname,
      path: url.pathname + url.search,
      method: 'GET',
      headers: {
        'apikey': SERVICE_KEY,
        'Authorization': 'Bearer ' + SERVICE_KEY,
        'Content-Type': 'application/json',
        'Prefer': 'count=exact',
      }
    };
    const r = https.request(opts, (res) => {
      let data = '';
      res.on('data', c => data += c);
      res.on('end', () => {
        try { resolve(JSON.parse(data)); }
        catch { resolve({ _raw: data }); }
      });
    });
    r.on('error', reject);
    r.end();
  });
}

async function main() {

  // ─── SORU 1: allergen_notification_log tablosu ───────────────────────────
  console.log('\n════════════════════════════════════════════════════════');
  console.log('SORU 1 — allergen_notification_log (son 10 kayıt)');
  console.log('════════════════════════════════════════════════════════');
  const logs = await req(
    '/rest/v1/allergen_notification_log' +
    '?select=id,recipient_type,status,scenario,error_message,telegram_user_id,staff_full_name,created_at' +
    '&order=created_at.desc&limit=10'
  );
  if (!Array.isArray(logs) || logs.length === 0) {
    console.log('❌ KAYIT YOK — allergen_notification_log tablosu BOŞ (veya tablo yok)');
    if (logs && logs.message) console.log('   Hata:', logs.message);
  } else {
    logs.forEach((r, i) => {
      console.log(`\n  [${i+1}] id=${r.id}`);
      console.log(`      recipient_type : ${r.recipient_type}`);
      console.log(`      status         : ${r.status}`);
      console.log(`      scenario       : ${r.scenario}`);
      console.log(`      telegram_id    : ${r.telegram_user_id}`);
      console.log(`      staff          : ${r.staff_full_name}`);
      console.log(`      error_message  : ${r.error_message ?? '(yok)'}`);
      console.log(`      created_at     : ${r.created_at}`);
    });
  }

  // ─── SORU 2: guest_allergens son kayıt ──────────────────────────────────
  console.log('\n════════════════════════════════════════════════════════');
  console.log('SORU 2 — guest_allergens (en son kayıt, tüm alanlar)');
  console.log('════════════════════════════════════════════════════════');
  const ga = await req(
    '/rest/v1/guest_allergens' +
    '?select=id,platform,platform_user_id,status,allergen_text,room_number,guest_full_name,reported_at,is_active,created_at,updated_at' +
    '&order=created_at.desc&limit=1'
  );
  if (!Array.isArray(ga) || ga.length === 0) {
    console.log('❌ guest_allergens tablosu BOŞ veya tablo yok');
  } else {
    const r = ga[0];
    console.log('  id              :', r.id);
    console.log('  platform        :', r.platform);
    console.log('  platform_user_id:', r.platform_user_id);
    console.log('  status          :', r.status);
    console.log('  allergen_text   :', r.allergen_text);
    console.log('  room_number     :', r.room_number ?? '(NULL)');
    console.log('  guest_full_name :', r.guest_full_name ?? '(NULL)');
    console.log('  reported_at     :', r.reported_at ?? '(NULL)');
    console.log('  is_active       :', r.is_active);
    console.log('  created_at      :', r.created_at);
    console.log('  updated_at      :', r.updated_at);

    // room_number doluysa inhouse_guests_v2'de eşleşme var mı?
    if (r.room_number) {
      console.log(`\n  → inhouse_guests_v2 sorgusu: room_number='${r.room_number}' status='active'`);
      const inhouseCheck = await req(
        '/rest/v1/inhouse_guests_v2' +
        `?select=id,guest_name,room_number,status,telegram_id` +
        `&room_number=eq.${encodeURIComponent(r.room_number)}&status=eq.active`
      );
      if (!Array.isArray(inhouseCheck) || inhouseCheck.length === 0) {
        console.log('  → ❌ Eşleşme YOK → SENARYO B (sadece GR bildirimi gitmeli)');
      } else {
        console.log(`  → ✅ Eşleşme VAR (${inhouseCheck.length} kayıt) → SENARYO A`);
        inhouseCheck.forEach(g => {
          console.log(`     guest_name=${g.guest_name} room=${g.room_number} status=${g.status} telegram_id=${g.telegram_id}`);
        });
      }
    } else {
      console.log('\n  → room_number NULL → SENARYO C (bildirim GİTMEMELİ)');
    }
  }

  // ─── SORU 4: department_staff FB primary ────────────────────────────────
  console.log('\n════════════════════════════════════════════════════════');
  console.log('SORU 4 — department_staff: fb + is_allergen_primary=true + is_active=true');
  console.log('════════════════════════════════════════════════════════');
  const fbPrimary = await req(
    '/rest/v1/department_staff' +
    '?select=id,full_name,telegram_user_id,department_key,is_allergen_primary,is_allergen_backup,is_manager,is_active' +
    '&department_key=eq.fb&is_active=eq.true&is_allergen_primary=eq.true'
  );
  if (!Array.isArray(fbPrimary) || fbPrimary.length === 0) {
    console.log('❌ FB primary personel BULUNAMADI (department_key=fb AND is_allergen_primary=true AND is_active=true)');
    if (fbPrimary && fbPrimary.message) console.log('   Hata:', fbPrimary.message);
  } else {
    console.log(`✅ ${fbPrimary.length} kayıt bulundu:`);
    fbPrimary.forEach(s => {
      console.log(`\n  full_name          : ${s.full_name}`);
      console.log(`  telegram_user_id   : ${s.telegram_user_id ?? '(NULL)'}`);
      console.log(`  department_key     : ${s.department_key}`);
      console.log(`  is_allergen_primary: ${s.is_allergen_primary}`);
      console.log(`  is_allergen_backup : ${s.is_allergen_backup}`);
      console.log(`  is_manager         : ${s.is_manager}`);
      console.log(`  is_active          : ${s.is_active}`);
    });
  }

  // ─── BONUS: Tüm FB personeli (is_active filtresi yok) ───────────────────
  console.log('\n════════════════════════════════════════════════════════');
  console.log('BONUS — department_staff: department_key=fb (tümü)');
  console.log('════════════════════════════════════════════════════════');
  const fbAll = await req(
    '/rest/v1/department_staff' +
    '?select=id,full_name,telegram_user_id,department_key,is_allergen_primary,is_allergen_backup,is_manager,is_active' +
    '&department_key=eq.fb'
  );
  if (!Array.isArray(fbAll) || fbAll.length === 0) {
    console.log('❌ Hiç FB personeli yok');
  } else {
    console.log(`${fbAll.length} kayıt:`);
    fbAll.forEach(s => {
      console.log(`  ${s.full_name} | telegram=${s.telegram_user_id} | active=${s.is_active} | primary=${s.is_allergen_primary} | backup=${s.is_allergen_backup}`);
    });
  }

  // ─── BONUS 2: guest_allergens hepsi (son 5) ─────────────────────────────
  console.log('\n════════════════════════════════════════════════════════');
  console.log('BONUS 2 — guest_allergens (son 5 kayıt, status+room_number)');
  console.log('════════════════════════════════════════════════════════');
  const gaAll = await req(
    '/rest/v1/guest_allergens' +
    '?select=id,status,allergen_text,room_number,platform_user_id,created_at' +
    '&order=created_at.desc&limit=5'
  );
  if (!Array.isArray(gaAll) || gaAll.length === 0) {
    console.log('(kayıt yok)');
  } else {
    gaAll.forEach((r, i) => {
      console.log(`  [${i+1}] status=${r.status} room=${r.room_number ?? 'NULL'} allergen="${r.allergen_text ?? ''}" user=${r.platform_user_id} at=${r.created_at}`);
    });
  }

  console.log('\n════ TEŞHİS TAMAMLANDI ════\n');
}

main().catch(e => console.error('SCRIPT HATA:', e.message));
