/**
 * T1-T3 test senaryoları: detectInterestTag FIX 2a doğrulama
 * node --experimental-specifier-resolution=node scratch_test_normalize.mjs
 */

// normalizeTr inline (aynı utils/normalize-tr.ts mantığı — sıra kritik!)
function normalizeTr(s) {
  return s
    .replace(/İ/g, 'i')   // büyük İ ÖNCE (toLowerCase sonrası i+combining dot olur!)
    .replace(/I/g, 'i')   // büyük I (Türkçe)
    .replace(/Ş/g, 's')
    .replace(/Ğ/g, 'g')
    .replace(/Ü/g, 'u')
    .replace(/Ö/g, 'o')
    .replace(/Ç/g, 'c')
    .toLowerCase()
    .replace(/ş/g, 's')
    .replace(/ğ/g, 'g')
    .replace(/ü/g, 'u')
    .replace(/ö/g, 'o')
    .replace(/ç/g, 'c')
    .replace(/ı/g, 'i');
}

function detectInterestTag(message) {
  const text = normalizeTr(message); // FIX 2a
  const map = {
    restaurant: ['restoran', 'yemek', 'yemegi', 'yemeği', 'lokanta', 'kebap', 'kahvalti', 'yiyecek', 'ogle', 'aksam yemek', 'aksam yemegi'],
    pharmacy:   ['eczane', 'ilac', 'ilaci', 'ilacim', 'nobetci', 'nobetci eczane'],

    museum:     ['muze', 'tarihi', 'antik', 'kale', 'cami'],
    transport:  ['ulasim', 'otobus', 'dolmus', 'metro', 'tramvay', 'taksi', 'havalimani'],
    atm:        ['atm', 'banka', 'para cek', 'doviz'],
    shopping:   ['alisveris', 'avm', 'market', 'magaza', 'pazar', 'carsi'],
    hospital:   ['hastane', 'doktor', 'klinik', 'acil'],
    beach:      ['plaj', 'sahil', 'deniz'],
    attraction: ['gezi', 'tur', 'aktivite', 'park', 'aquapark', 'akvaryum'],
    nightlife:  ['bar', 'gece', 'kulup', 'eglence'],
  };
  for (const [tag, keywords] of Object.entries(map)) {
    if (keywords.some((kw) => text.includes(normalizeTr(kw)))) return tag;
  }
  return null;
}

const tests = [
  // T1 — normal eczane (zaten çalışıyordu)
  { input: 'yakında eczane var mı',      expected: 'pharmacy', label: 'T1 eczane (baz)' },
  // T2 — İ ile başlayan kelime (FIX 2a kanıtı)
  { input: 'İlaç alabileceğim yer var mı', expected: 'pharmacy', label: 'T2 İlaç (büyük İ)' },
  { input: 'ilaç nerede bulabilirim',    expected: 'pharmacy', label: 'T2b ilaç (küçük)' },
  { input: 'ILAC alabileceğim yer',      expected: 'pharmacy', label: 'T2c ILAC (büyük İ→I)' },
  // T3 — Türkçe Ö/Ğ/ü büyük/küçük (yemek)
  { input: 'ÖĞLE yemeği nerede yenir',  expected: 'restaurant', label: 'T3 ÖĞLE (büyük)' },
  { input: 'öğle yemeği',               expected: 'restaurant', label: 'T3b öğle (küçük)' },
  // Regresyon — daha önce çalışan
  { input: 'plaj var mı',               expected: 'beach',      label: 'R1 plaj (regresyon)' },
  { input: 'ATM nerede',                expected: 'atm',        label: 'R2 ATM (büyük)' },
];

let passed = 0;
let failed = 0;
for (const t of tests) {
  const result = detectInterestTag(t.input);
  const ok = result === t.expected;
  if (ok) passed++;
  else failed++;
  const icon = ok ? '✅' : '❌';
  console.log(`${icon} ${t.label}`);
  console.log(`   input="${t.input}" → tag=${result} (expected=${t.expected})`);
}

console.log(`\n--- ${passed}/${tests.length} PASSED ---`);
if (failed > 0) {
  console.log(`❌ ${failed} FAILED`);
  process.exit(1);
}
