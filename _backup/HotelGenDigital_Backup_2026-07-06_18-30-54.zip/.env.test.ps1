
$env:BOT  = "8887001623:AAEKnxxWidK4QFrgyKnGc-kvTHe0DeHsbR4"

$env:CRON = "hgv2_cron_2026_x9K4mP7qR2wT5nLjY6vBcZ3sA1uH8fG"

$env:PREVIEW = "https://hotelgen-v2-git-hotelgen-v4-hotelgendigital.vercel.app"

