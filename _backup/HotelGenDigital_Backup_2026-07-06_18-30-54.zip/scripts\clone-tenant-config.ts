/**
 * clone-tenant-config.ts — TEK SEFERLİK config/içerik kopyalama script'i
 *
 * Amaç:
 *   Kaynak tenant otelden hedef tenant otele SADECE config/içerik tablolarını
 *   kopyalar. Misafir / konuşma / operasyon tablolarına ASLA dokunmaz.
 *
 * Çalıştırma:
 *   npx tsx scripts/clone-tenant-config.ts
 *
 * Gerekli env (.env.local — yeni key EKLENMEZ):
 *   CENTRAL_SUPABASE_URL, CENTRAL_SUPABASE_SERVICE_ROLE_KEY  (helper'lar kullanır)
 *   ENCRYPTION_MASTER_KEY                                     (bridge decrypt)
 *
 * NOT: Bağlantılar bridge_credentials'tan çözülür (getHotelBySlug + getDecryptedBridge).
 *      Tenant Supabase URL/service_role key'leri env'e EKLENMEZ.
 */

// .env.local'i import'lardan ÖNCE yükle (helper'lar env'i lazy okur, yine de garanti).
import * as dotenv from 'dotenv'
import * as path from 'path'
import * as fs from 'fs'

const envPath = path.resolve(process.cwd(), '.env.local')
if (fs.existsSync(envPath)) {
  dotenv.config({ path: envPath })
} else {
  dotenv.config()
}

import { createClient, SupabaseClient } from '@supabase/supabase-js'
import { getHotelBySlug } from '@/lib/tenant/get-hotel-by-slug'
import { getDecryptedBridge } from '@/lib/tenant/decrypt-credentials'

// ===========================================================================
// SABİTLER — kaynak ve hedef tenant slug'ları
// ===========================================================================
const SOURCE = 'green-park-otel-demo'
const TARGET = 'regnum-hotels-belek'

// Büyük tablolar için insert batch boyutu.
const BATCH = 500

// ===========================================================================
// KOPYALANACAK TABLOLAR — bu SIRADA (FK parent → child sırası korunur).
//   parent'lar child'lardan ÖNCE:
//     hotel_documents       → document_chunks
//     technical_subcategories → technical_staff_subcategories
//     knowledge_documents   → knowledge_sections
// ===========================================================================
const CONFIG_TABLES = [
  'hotel_settings',
  'hotel_facts',
  'departments',
  'department_staff',
  'technical_subcategories',
  'reservation_links',
  'perplexity_discoveries',
  'excel_column_mapping',
  'hotel_documents',
  'knowledge_documents',
  'document_chunks',
  'technical_staff_subcategories',
  'knowledge_sections',
] as const

// ===========================================================================
// KOPYALANMAYACAK — sadece dokümantasyon amaçlı (KOD BUNLARA DOKUNMAZ).
//   hotel_admin_users        → Regnum admin'i zaten oluşturuldu, kopyalanmaz.
//   conversations, bot_messages, ai_intents, forwarded_messages,
//   conversation_summary, customer_facts(_archive), guest_facts,
//   requests, sla_events, sla_violations, critical_word_escalations,
//   fb_room_service_orders, verification_attempts,
//   inhouse_guests, inhouse_guests_v2, inhouse_upload_history, inhouse_archive,
//   late_checkout_notifications, pending_guest_matches,
//   allergic_guests, guest_allergens, allergen_notification_log,
//   lost_items, dnd_list, knowledge_answers, schema_migrations
// ===========================================================================

// ---------------------------------------------------------------------------
// Bir slug için service_role tenant client kur (bridge'ten decrypt ederek).
// ---------------------------------------------------------------------------
async function resolveTenantClient(slug: string): Promise<{
  client: SupabaseClient
  hotelId: string
  name: string
  urlHost: string
}> {
  const hotel = await getHotelBySlug(slug)
  if (!hotel) {
    throw new Error(`Otel bulunamadı (slug=${slug})`)
  }

  const bridge = await getDecryptedBridge(hotel.id)
  if (!bridge) {
    throw new Error(`Bridge credentials bulunamadı (slug=${slug}, id=${hotel.id})`)
  }

  const client = createClient(bridge.supabaseUrl, bridge.supabaseServiceKey, {
    auth: { persistSession: false, autoRefreshToken: false },
  })

  let urlHost = bridge.supabaseUrl
  try {
    urlHost = new URL(bridge.supabaseUrl).host
  } catch {
    /* host parse edilemezse ham değeri bırak */
  }

  return { client, hotelId: hotel.id, name: hotel.name, urlHost }
}

// ---------------------------------------------------------------------------
// Tek bir tabloyu kaynaktan hedefe kopyala.
//   - Kaynaktan tüm satırları SELECT * eder.
//   - Hedefe id'ler dahil olduğu gibi upsert eder (onConflict: 'id').
//   - Hedef tabloyu TEMİZLEMEZ; conflict olursa günceller.
// Döner: kopyalanan satır sayısı.
// ---------------------------------------------------------------------------
async function copyTable(
  source: SupabaseClient,
  target: SupabaseClient,
  table: string
): Promise<number> {
  const { data: rows, error: selErr } = await source.from(table).select('*')
  if (selErr) {
    throw new Error(`SELECT hatası [${table}]: ${selErr.message}`)
  }

  const all = rows ?? []
  if (all.length === 0) {
    return 0
  }

  let written = 0
  for (let i = 0; i < all.length; i += BATCH) {
    const chunk = all.slice(i, i + BATCH)
    const { error: upErr } = await target
      .from(table)
      .upsert(chunk, { onConflict: 'id' })
    if (upErr) {
      throw new Error(
        `UPSERT hatası [${table}] (batch ${i}-${i + chunk.length}): ${upErr.message}`
      )
    }
    written += chunk.length
  }

  return written
}

// ---------------------------------------------------------------------------
// main
// ---------------------------------------------------------------------------
async function main() {
  console.log('\n╔══════════════════════════════════════════════════════════════════╗')
  console.log('║            TENANT CONFIG KOPYALAMA (tek seferlik)                ║')
  console.log('╚══════════════════════════════════════════════════════════════════╝\n')

  if (SOURCE === TARGET) {
    console.error('❌ SOURCE ve TARGET aynı olamaz. Çıkılıyor.')
    process.exit(1)
  }

  console.log(`Kaynak (SOURCE): ${SOURCE}`)
  console.log(`Hedef  (TARGET): ${TARGET}\n`)

  // Bağlantıları çöz
  const src = await resolveTenantClient(SOURCE)
  const tgt = await resolveTenantClient(TARGET)

  if (src.hotelId === tgt.hotelId) {
    console.error('❌ Kaynak ve hedef aynı otel (aynı hotelId). Çıkılıyor.')
    process.exit(1)
  }

  console.log(`✔ Kaynak çözüldü: ${src.name} (${src.urlHost})`)
  console.log(`✔ Hedef çözüldü : ${tgt.name} (${tgt.urlHost})\n`)
  console.log(`Kopyalanacak ${CONFIG_TABLES.length} tablo (FK sırasıyla)...\n`)

  // Tablo bazında özet
  const summary: { table: string; copied: number | null; error?: string }[] = []

  for (const table of CONFIG_TABLES) {
    process.stdout.write(`→ ${table} ... `)
    try {
      const n = await copyTable(src.client, tgt.client, table)
      summary.push({ table, copied: n })
      console.log(`${n} satır kopyalandı`)
    } catch (e) {
      const msg = e instanceof Error ? e.message : String(e)
      summary.push({ table, copied: null, error: msg })
      console.log(`HATA: ${msg}`)
    }
  }

  // ---- ÖZET ----
  console.log('\n──────────────────────────────────────────────────────────────────')
  console.log('ÖZET')
  console.log('──────────────────────────────────────────────────────────────────')
  let totalRows = 0
  let failed = 0
  for (const s of summary) {
    if (s.copied === null) {
      failed++
      console.log(`  ✗ ${s.table.padEnd(30)} HATA: ${s.error}`)
    } else {
      totalRows += s.copied
      console.log(`  ✓ ${s.table.padEnd(30)} ${s.copied} satır kopyalandı`)
    }
  }
  console.log('──────────────────────────────────────────────────────────────────')
  console.log(`Toplam: ${totalRows} satır, ${summary.length} tablo, ${failed} hata`)
  console.log('──────────────────────────────────────────────────────────────────\n')

  if (failed > 0) {
    process.exit(1)
  }
}

main().catch((e) => {
  console.error('\n❌ FATAL:', e instanceof Error ? e.message : e)
  process.exit(1)
})
