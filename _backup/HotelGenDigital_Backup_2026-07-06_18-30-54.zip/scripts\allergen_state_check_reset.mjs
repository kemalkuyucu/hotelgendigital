// Allergen state check + reset — fetch tabanlı (Node 20 uyumlu)
const SUPABASE_URL = 'https://rvsyvegfeywzqbqljlij.supabase.co';
const KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJ2c3l2ZWdmZXl3enFicWxqbGlqIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc3Nzk3MzQ2OCwiZXhwIjoyMDkzNTQ5NDY4fQ.T1NtIugkuxcX0sLcw3LVDavJHLhdXzjwR4FO2oDiEio';

const headers = {
  'apikey': KEY,
  'Authorization': `Bearer ${KEY}`,
  'Content-Type': 'application/json',
  'Prefer': 'return=representation',
};

async function pgQuery(method, path, body = null) {
  const url = `${SUPABASE_URL}/rest/v1/${path}`;
  const opts = { method, headers };
  if (body) opts.body = JSON.stringify(body);
  const res = await fetch(url, opts);
  const text = await res.text();
  if (!res.ok) throw new Error(`${res.status} ${res.statusText}: ${text}`);
  return text ? JSON.parse(text) : [];
}

console.log('='.repeat(60));
console.log('ADIM 1 — MEVCUT DURUM (sıfırlamadan ÖNCE)');
console.log('='.repeat(60));

// conversations — son 5, allergen alanlarıyla
console.log('\n📋 conversations (son 5, updated_at DESC):');
try {
  const cols = 'id,telegram_chat_id,allergen_asked,allergen_pending,verification_pending_intent,verified_at,updated_at';
  const convs = await pgQuery('GET', `conversations?select=${cols}&order=updated_at.desc&limit=5`);
  if (!convs.length) {
    console.log('  ⚠️  Kayıt yok.');
  } else {
    for (const c of convs) {
      console.log('  ---');
      console.log('  id                        :', c.id);
      console.log('  telegram_chat_id          :', c.telegram_chat_id);
      console.log('  allergen_asked            :', c.allergen_asked);
      console.log('  allergen_pending          :', c.allergen_pending);
      console.log('  verification_pending_intent:', c.verification_pending_intent);
      console.log('  verified_at               :', c.verified_at);
      console.log('  updated_at                :', c.updated_at);
    }
  }
} catch (e) {
  console.error('  ❌ conversations hatası:', e.message);
}

// guest_allergens — tüm kayıtlar
console.log('\n🥜 guest_allergens (tümü):');
try {
  const cols = 'id,platform_user_id,status,allergen_text,asked_at,room_number,created_at,updated_at';
  const allergens = await pgQuery('GET', `guest_allergens?select=${cols}&order=created_at.desc`);
  if (!allergens.length) {
    console.log('  ⚠️  guest_allergens tablosunda hiç kayıt yok.');
  } else {
    for (const a of allergens) {
      console.log('  ---');
      console.log('  id              :', a.id);
      console.log('  platform_user_id:', a.platform_user_id);
      console.log('  status          :', a.status);
      console.log('  allergen_text   :', a.allergen_text);
      console.log('  asked_at        :', a.asked_at);
      console.log('  room_number     :', a.room_number);
      console.log('  created_at      :', a.created_at);
      console.log('  updated_at      :', a.updated_at);
    }
  }
} catch (e) {
  console.error('  ❌ guest_allergens hatası:', e.message);
}

console.log('\n' + '='.repeat(60));
console.log('ADIM 2 — SIFIRLAMA');
console.log('='.repeat(60));

// conversations: allergen_asked=false, allergen_pending=false yap
// Filtre: allergen_asked=true OR allergen_pending=true
console.log('\n🔄 conversations: allergen_asked=false, allergen_pending=false yapılıyor...');
try {
  // allergen_asked=true olanlar
  let updated1 = [];
  try {
    updated1 = await pgQuery(
      'PATCH',
      'conversations?allergen_asked=eq.true',
      { allergen_asked: false, allergen_pending: false }
    );
  } catch (e) { console.log('  (allergen_asked=true: kayıt yok veya hata:', e.message, ')'); }

  // allergen_pending=true olanlar (hâlâ true olanlar)
  let updated2 = [];
  try {
    updated2 = await pgQuery(
      'PATCH',
      'conversations?allergen_pending=eq.true',
      { allergen_asked: false, allergen_pending: false }
    );
  } catch (e) { console.log('  (allergen_pending=true: kayıt yok veya hata:', e.message, ')'); }

  const total = updated1.length + updated2.length;
  if (total === 0) {
    console.log('  ✅ Zaten false olan kayıt var (ya da güncellenecek kayıt yoktu).');
  } else {
    console.log(`  ✅ Toplam ${total} kayıt güncellendi.`);
    for (const c of [...updated1, ...updated2]) {
      console.log(`     → id=${c.id} | chat_id=${c.telegram_chat_id} | allergen_asked=${c.allergen_asked} | allergen_pending=${c.allergen_pending}`);
    }
  }
} catch (e) {
  console.error('  ❌ conversations güncelleme hatası:', e.message);
}

// guest_allergens: hard-delete tüm kayıtlar
console.log('\n🗑️  guest_allergens: hard-delete yapılıyor...');
try {
  const deleted = await pgQuery('DELETE', 'guest_allergens?id=not.is.null');
  if (!deleted.length) {
    console.log('  ✅ Silinecek kayıt yoktu (tablo zaten boştu).');
  } else {
    console.log(`  ✅ ${deleted.length} kayıt silindi:`);
    for (const a of deleted) {
      console.log(`     → id=${a.id} | platform_user_id=${a.platform_user_id} | status=${a.status}`);
    }
  }
} catch (e) {
  console.error('  ❌ guest_allergens silme hatası:', e.message);
}

// Doğrulama: sıfırlamadan sonra conversations durumu
console.log('\n🔍 Doğrulama — conversations son durumu (sıfırlamadan SONRA):');
try {
  const cols = 'id,telegram_chat_id,allergen_asked,allergen_pending,verification_pending_intent,updated_at';
  const convs2 = await pgQuery('GET', `conversations?select=${cols}&order=updated_at.desc&limit=5`);
  for (const c of convs2) {
    console.log(`  id=${c.id} | chat_id=${c.telegram_chat_id} | allergen_asked=${c.allergen_asked} | allergen_pending=${c.allergen_pending}`);
  }
} catch (e) {
  console.error('  ❌', e.message);
}

console.log('\n' + '='.repeat(60));
console.log('İŞLEM TAMAMLANDI ✅');
console.log('='.repeat(60));
