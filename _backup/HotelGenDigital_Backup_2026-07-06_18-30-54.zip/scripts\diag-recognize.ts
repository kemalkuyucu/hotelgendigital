/**
 * diag-recognize.ts — TEŞHİS (geçici, route logic'ine dokunmaz)
 * Çalıştır: npx tsx scripts/diag-recognize.ts
 *
 * Webhook route'unun KULLANDIĞI gerçek tenant-client zinciri:
 *   getHotelBySlug(slug) -> hotel.id  (@/lib/tenant/get-hotel-by-slug)
 *   getHotelClient(hotel.id) -> SupabaseClient  (@/lib/tenant/get-hotel-client)
 * (route.ts:170 getSupaClientForSlug bu ikisini zincirliyor; getHotelClient slug değil hotelId alıyor.)
 */

import * as dotenv from 'dotenv';
import * as path from 'path';
import * as fs from 'fs';

// .env.local yükle (repo konvansiyonu — cleanup-pending-matches.ts ile aynı)
const envPath = path.resolve(process.cwd(), '.env.local');
if (fs.existsSync(envPath)) {
  dotenv.config({ path: envPath });
} else {
  dotenv.config();
}

import { getHotelBySlug } from '../src/lib/tenant/get-hotel-by-slug';
import { getHotelClient } from '../src/lib/tenant/get-hotel-client';

async function main() {
  const slug = 'regnum-hotels-belek';
  const tgId = '758605940';

  // app'in kullandığı client (getHotelBySlug -> getHotelClient zinciri)
  const hotel = await getHotelBySlug(slug);
  console.log('HOTEL =', JSON.stringify(hotel ? { id: hotel.id, status: (hotel as any).status } : null));
  if (!hotel) { console.error('HOTEL_NOT_FOUND'); process.exit(1); }
  const supa = await getHotelClient(hotel.id);
  if (!supa) { console.error('CLIENT_NULL (bridge decrypt başarısız)'); process.exit(1); }

  // hangi DB'ye bağlandık:
  console.log('CONNECTED_URL =', (supa as any).supabaseUrl ?? (supa as any).rest?.url ?? 'bilinmiyor');

  const today = new Date().toISOString().slice(0, 10);

  // A) PART C sorgusunun BIREBIR ayni'si
  const partC = await supa.from('inhouse_guests_v2')
    .select('id, guest_name, room_number, status, check_out_date, telegram_id')
    .eq('telegram_id', tgId).eq('status', 'active').gte('check_out_date', today);
  console.log('PART_C_ROWS =', JSON.stringify(partC.data), 'ERR=', partC.error?.message);

  // B) bu tgId herhangi bir satira damgali mi (status/tarih filtresiz)
  const anyStamp = await supa.from('inhouse_guests_v2')
    .select('id, guest_name, room_number, status, check_out_date, telegram_id')
    .eq('telegram_id', tgId);
  console.log('ANY_STAMP =', JSON.stringify(anyStamp.data));

  // C) conversation tanima alanlari
  const conv = await supa.from('conversations')
    .select('telegram_chat_id, verified_inhouse_guest_id, verified_at, verification_attempts')
    .eq('telegram_chat_id', tgId);
  console.log('CONV =', JSON.stringify(conv.data));
}
main().catch(e => { console.error('DIAG_ERR', e); process.exit(1); });
