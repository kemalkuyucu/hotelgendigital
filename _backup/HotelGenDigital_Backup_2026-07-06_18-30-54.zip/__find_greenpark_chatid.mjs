import { readFileSync } from 'fs';
const env = readFileSync('.env.local', 'utf8');
const getEnv = (key) => {
  const lines = env.split('\n');
  for (const line of lines) {
    if (line.startsWith(key + '=')) return line.slice(key.length + 1).replace(/^["']|["']\s*$/g, '').trim();
  }
  return null;
};

// Central Supabase'den otel ve bridge_credentials'ı çek
const centralUrl = getEnv('CENTRAL_SUPABASE_URL');
const centralKey = getEnv('CENTRAL_SUPABASE_SERVICE_ROLE_KEY');

console.log('Central URL:', centralUrl || '(empty!)');

if (!centralUrl) {
  console.log('\n=== CENTRAL_SUPABASE_URL boş — Demo hotel DB\'den bulmaya çalışıyoruz ===\n');
  
  // Demo hotel DB'sine bak
  const demoUrl = getEnv('DEMO_HOTEL_SUPABASE_URL');
  const demoKey = getEnv('DEMO_HOTEL_SUPABASE_SERVICE_ROLE_KEY');
  
  // Tüm tabloları tekrar listele - bridge_credentials dahil
  const r = await fetch(`${demoUrl}/rest/v1/?apikey=${demoKey}`, {
    headers: { 'Authorization': `Bearer ${demoKey}`, 'Accept': 'application/json' }
  });
  const schema = await r.json();
  if (schema.paths) {
    const paths = Object.keys(schema.paths).filter(p => !p.includes('rpc'));
    console.log('All tables:', paths.join(', '));
    
    // bridge_credentials tablosu var mı?
    if (paths.includes('/bridge_credentials')) {
      const br = await fetch(`${demoUrl}/rest/v1/bridge_credentials?select=*&limit=10`, {
        headers: { 'apikey': demoKey, 'Authorization': `Bearer ${demoKey}`, 'Accept': 'application/json' }
      });
      const brData = await br.json();
      console.log('\n=== bridge_credentials ===');
      console.log(JSON.stringify(brData, null, 2));
    }
  }
}
