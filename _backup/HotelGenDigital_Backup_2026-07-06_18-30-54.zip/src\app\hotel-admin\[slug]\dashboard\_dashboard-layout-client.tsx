'use client'

import Link from 'next/link'
import { usePathname, useRouter } from 'next/navigation'
import { useState, useEffect } from 'react'
import type { HotelAdminRole, DepartmentKey } from '@/lib/hotel-admin/types'
import { getAllowedDepartments, deptLabel, roleLabel } from '@/lib/hotel-admin/types'

interface Props {
  slug: string
  adminName: string
  adminRole: HotelAdminRole
  children: React.ReactNode
}

type NavItemKey =
  | DepartmentKey
  | 'dashboard'
  | 'fo-list'
  | 'fo-upload'
  | 'fo-menu'
  | 'spa-menu'
  | 'fo-history'
  | 'fo-rez-links'
  | 'fo-fiyat'
  | 'bilgi-otel'
  | 'bilgi-tabani'
  | 'belgeler'
  | 'cevre-kesfi'
  | 'toplanti-salonlari'
  | 'eskalasyon'
  | 'departman-personeli'
  | 'raporlama'

interface NavItem {
  key: NavItemKey
  label: string
  href: string
  isSubItem?: boolean
}

/** Hangi roller ön büro alt menüsünü görür */
const FRONT_OFFICE_ROLES: HotelAdminRole[] = ['hotel_owner', 'front_office_manager']

/** Hangi roller bilgi yönetimi bölümünü görür */
const BILGI_ROLES: HotelAdminRole[] = ['hotel_owner']

/** Hangi roller departman personeli görebilir */
const PERSONEL_ROLES: HotelAdminRole[] = [
  'hotel_owner',
  'front_office_manager',
  'housekeeping_manager',
  'technical_manager',
  'fb_manager',
  'guest_relation_manager',
  'spa_manager',
  'animation_manager',
]

export default function DashboardLayoutClient({ slug, adminName, adminRole, children }: Props) {
  const pathname = usePathname()
  const router = useRouter()
  const [loggingOut, setLoggingOut] = useState(false)

  // mobil sidebar (dar ekranda gizli + hamburger overlay)
  const [isMobile, setIsMobile] = useState(false)
  const [mobileOpen, setMobileOpen] = useState(false)
  useEffect(() => {
    const mq = window.matchMedia('(max-width: 768px)')
    const apply = () => setIsMobile(mq.matches)
    apply()
    mq.addEventListener('change', apply)
    return () => mq.removeEventListener('change', apply)
  }, [])
  useEffect(() => { setMobileOpen(false) }, [pathname])

  // Akordiyon: hangi alt-grup bölümü açık (tek seferde bir tane).
  // Default: aktif sayfanın ait olduğu bölüm; eşleşme yoksa Ön Büro.
  const sectionForPath = (p: string): string | null => {
    if (p.includes('/menu-yukle')) return 'fb'
    if (p.includes('/spa-yukle')) return 'spa'
    if (p.includes('/bilgi-yonetimi')) return 'bilgi'
    if (p.includes('/departman-personeli')) return 'personel'
    if (p.includes('/front-office') || p.includes('/reservation-links') || p.includes('/fiyat-yukle')) return 'front-office'
    return null
  }
  const [openSection, setOpenSection] = useState<string | null>(() => sectionForPath(pathname) ?? 'front-office')
  const toggleSection = (id: string) => setOpenSection((prev) => (prev === id ? null : id))

  const allowedDepts = getAllowedDepartments(adminRole)

  // Ana nav: Dashboard + departmanlar (Misafirler kaldırıldı)
  const navItems: NavItem[] = [
    { key: 'dashboard', label: '📊 Dashboard', href: `/hotel-admin/${slug}/dashboard` },
    ...allowedDepts.map((dept) => ({
      key: dept,
      label: deptLabel(dept),
      href: `/hotel-admin/${slug}/dashboard/${dept}`,
    })),
    { key: 'raporlama', label: 'Raporlama', href: `/hotel-admin/${slug}/raporlama` },
  ]

  // Ön Büro alt menü (sadece hotel_owner ve front_office_manager)
  const showFrontOffice = FRONT_OFFICE_ROLES.includes(adminRole)
  const showFbMenu = adminRole === 'hotel_owner' || adminRole === 'fb_manager'
  const showSpaMenu = adminRole === 'hotel_owner' || adminRole === 'spa_manager'
  const showPersonel = PERSONEL_ROLES.includes(adminRole)
  const frontOfficeItems: NavItem[] = [
    { key: 'fo-list',      label: 'In-House Listesi',     href: `/hotel-admin/${slug}/front-office`,              isSubItem: true },
    { key: 'fo-upload',   label: 'Excel Yükle',           href: `/hotel-admin/${slug}/front-office/upload`,       isSubItem: true },
    { key: 'fo-history',  label: 'Bildirim Geçmişi',      href: `/hotel-admin/${slug}/front-office/history`,      isSubItem: true },
    { key: 'fo-rez-links',label: '🔗 Rezervasyon Linkleri', href: `/hotel-admin/${slug}/dashboard/reservation-links`, isSubItem: true },
    { key: 'fo-fiyat',    label: '🏷️ Fiyat Yükle',          href: `/hotel-admin/${slug}/fiyat-yukle`,                isSubItem: true },
  ]

  const fbMenuItems: NavItem[] = [
    { key: 'fo-menu', label: '🍽️ Menü Yükle', href: `/hotel-admin/${slug}/menu-yukle`, isSubItem: true },
  ]

  const spaMenuItems: NavItem[] = [
    { key: 'spa-menu', label: '🧖 Hizmet Listesi', href: `/hotel-admin/${slug}/spa-yukle`, isSubItem: true },
  ]

  // Bilgi Yönetimi alt menü (sadece hotel_owner)
  const showBilgiYonetimi = BILGI_ROLES.includes(adminRole)
  const bilgiItems: NavItem[] = [
    { key: 'bilgi-otel',         label: 'Otel Bilgileri',        href: `/hotel-admin/${slug}/bilgi-yonetimi/otel-bilgileri`,      isSubItem: true },
    { key: 'bilgi-tabani',       label: 'Bilgi Tabanı',          href: `/hotel-admin/${slug}/bilgi-yonetimi/bilgi-tabani`,         isSubItem: true },
    { key: 'belgeler',           label: 'Belgeler',               href: `/hotel-admin/${slug}/bilgi-yonetimi/belgeler`,             isSubItem: true },
    { key: 'cevre-kesfi',        label: 'Çevre Keşfi',           href: `/hotel-admin/${slug}/bilgi-yonetimi/cevre-kesfi`,          isSubItem: true },
    { key: 'toplanti-salonlari', label: '🏛️ Toplantı Salonları', href: `/hotel-admin/${slug}/bilgi-yonetimi/toplanti-salonlari`,   isSubItem: true },
    { key: 'eskalasyon', label: 'Eskalasyon', href: `/hotel-admin/${slug}/bilgi-yonetimi/eskalasyon`, isSubItem: true },
  ]

  async function handleLogout() {
    setLoggingOut(true)
    await fetch('/api/hotel-admin/logout', { method: 'POST' })
    router.push(`/hotel-admin/${slug}/login`)
  }

  const linkStyle = (isActive: boolean, isSubItem?: boolean): React.CSSProperties => ({
    display: 'block',
    padding: isSubItem ? '8px 14px 8px 24px' : '10px 14px',
    borderRadius: '10px',
    fontSize: isSubItem ? '13px' : '13.5px',
    fontWeight: isActive ? 600 : 400,
    color: isActive ? (isSubItem ? '#7dd3fc' : '#a5b4fc') : '#94a3b8',
    background: isActive
      ? isSubItem ? 'rgba(56,189,248,0.12)' : 'rgba(99,102,241,0.15)'
      : 'transparent',
    border: isActive
      ? isSubItem ? '1px solid rgba(56,189,248,0.2)' : '1px solid rgba(99,102,241,0.25)'
      : '1px solid transparent',
    textDecoration: 'none',
    transition: 'all 0.15s',
  })

  // Tıklanabilir akordiyon başlığı: emoji + text + chevron (▶ kapalı / ▼ açık)
  const sectionHeader = (emoji: string, text: string, id: string) => {
    const isOpen = openSection === id
    return (
      <button
        onClick={() => toggleSection(id)}
        onMouseEnter={(e) => { e.currentTarget.style.background = 'rgba(255,255,255,0.04)' }}
        onMouseLeave={(e) => { e.currentTarget.style.background = 'transparent' }}
        style={{
          marginTop: '12px',
          marginBottom: '4px',
          padding: '6px 8px',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          width: '100%',
          background: 'transparent',
          border: 'none',
          borderRadius: '8px',
          cursor: 'pointer',
          transition: 'background 0.15s',
        }}
      >
        <span style={{
          fontSize: '10px',
          fontWeight: 700,
          color: '#64748b',
          textTransform: 'uppercase',
          letterSpacing: '0.08em',
        }}>
          {emoji} {text}
        </span>
        <span style={{ fontSize: '9px', color: '#64748b', lineHeight: 1 }}>
          {isOpen ? '▼' : '▶'}
        </span>
      </button>
    )
  }

  return (
    <div
      style={{
        minHeight: '100vh',
        display: 'flex',
        fontFamily: "'Inter', system-ui, sans-serif",
        background: 'transparent',
        width: '100%',
      }}
    >
      {/* Mobil hamburger butonu */}
      {isMobile && (
        <button
          onClick={() => setMobileOpen((v) => !v)}
          aria-label="Menü"
          style={{
            position: 'fixed',
            top: 14,
            left: 14,
            zIndex: 60,
            width: 44,
            height: 44,
            borderRadius: 12,
            background: 'rgba(10,15,30,0.92)',
            border: '1px solid rgba(255,255,255,0.12)',
            color: '#f1f5f9',
            fontSize: 20,
            cursor: 'pointer',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            backdropFilter: 'blur(12px)',
            WebkitBackdropFilter: 'blur(12px)',
          }}
        >
          {mobileOpen ? '✕' : '☰'}
        </button>
      )}

      {/* Mobil overlay (arka plan karartma) */}
      {isMobile && mobileOpen && (
        <div
          onClick={() => setMobileOpen(false)}
          style={{
            position: 'fixed',
            inset: 0,
            background: 'rgba(0,0,0,0.55)',
            zIndex: 45,
          }}
        />
      )}

      {/* Sidebar */}
      <aside
        style={{
          width: '260px',
          minHeight: '100vh',
          background: 'rgba(10,15,30,0.85)',
          backdropFilter: 'blur(12px)',
          WebkitBackdropFilter: 'blur(12px)',
          borderRight: '1px solid rgba(255,255,255,0.08)',
          display: 'flex',
          flexDirection: 'column',
          flexShrink: 0,
          ...(isMobile
            ? {
                position: 'fixed',
                top: 0,
                left: 0,
                height: '100vh',
                zIndex: 50,
                transform: mobileOpen ? 'translateX(0)' : 'translateX(-100%)',
                transition: 'transform 0.25s ease',
              }
            : {}),
        }}
      >
        {/* Logo */}
        <div style={{ padding: '28px 24px', borderBottom: '1px solid rgba(255,255,255,0.08)' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
            <div
              style={{
                width: '40px',
                height: '40px',
                background: 'linear-gradient(135deg, #6366f1, #8b5cf6)',
                borderRadius: '10px',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                fontSize: '20px',
                flexShrink: 0,
              }}
            >
              🏨
            </div>
            <div>
              <p style={{ color: '#f1f5f9', fontSize: '15px', fontWeight: 700, margin: 0 }}>
                HotelGen
              </p>
              <p style={{ color: '#64748b', fontSize: '11px', margin: 0, fontFamily: 'monospace' }}>
                {slug}
              </p>
            </div>
          </div>
        </div>

        {/* Nav */}
        <nav style={{ flex: 1, padding: '16px 12px', display: 'flex', flexDirection: 'column', gap: '4px', overflowY: 'auto' }}>

          {/* Ana menü öğeleri (Dashboard + departmanlar) */}
          {navItems.map((item) => {
            const isActive = item.key === 'dashboard'
              ? pathname === item.href
              : pathname.startsWith(item.href)
            return (
              <Link key={item.key} href={item.href} style={linkStyle(isActive, false)}>
                {item.label}
              </Link>
            )
          })}

          {/* 🏨 Ön Büro Bölümü — sadece hotel_owner ve front_office_manager */}
          {showFrontOffice && (
            <>
              {sectionHeader('🏨', 'Ön Büro', 'front-office')}
              {openSection === 'front-office' && frontOfficeItems.map((item) => {
                const isActive = pathname === item.href || pathname.startsWith(item.href + '/')
                return (
                  <Link key={item.key} href={item.href} style={linkStyle(isActive, true)}>
                    {item.label}
                  </Link>
                )
              })}
            </>
          )}

          {/* 🍽️ F&B Bölümü — sadece hotel_owner ve fb_manager */}
          {showFbMenu && (
            <>
              {sectionHeader('🍽️', 'F&B', 'fb')}
              {openSection === 'fb' && fbMenuItems.map((item) => {
                const isActive = pathname === item.href || pathname.startsWith(item.href + '/')
                return (
                  <Link key={item.key} href={item.href} style={linkStyle(isActive, true)}>
                    {item.label}
                  </Link>
                )
              })}
            </>
          )}

          {/* 🧖 SPA Bölümü — sadece hotel_owner ve spa_manager */}
          {showSpaMenu && (
            <>
              {sectionHeader('🧖', 'SPA', 'spa')}
              {openSection === 'spa' && spaMenuItems.map((item) => {
                const isActive = pathname === item.href || pathname.startsWith(item.href + '/')
                return (
                  <Link key={item.key} href={item.href} style={linkStyle(isActive, true)}>
                    {item.label}
                  </Link>
                )
              })}
            </>
          )}

          {/* 👥 Personel Yönetimi — hotel_owner + tüm departman müdürleri */}
          {showPersonel && (
            <>
              {sectionHeader('👥', 'Personel', 'personel')}
              {openSection === 'personel' && (
                <Link
                  href={`/hotel-admin/${slug}/dashboard/departman-personeli`}
                  style={linkStyle(
                    pathname.startsWith(`/hotel-admin/${slug}/dashboard/departman-personeli`),
                    true
                  )}
                >
                  {adminRole === 'hotel_owner' ? '👁️ Departman Çalışanları' : '👥 Departman Çalışanları'}
                </Link>
              )}
            </>
          )}

          {/* 📚 Bilgi Yönetimi — sadece hotel_owner */}
          {showBilgiYonetimi && (
            <>
              {sectionHeader('📚', 'Bilgi Yönetimi', 'bilgi')}
              {openSection === 'bilgi' && bilgiItems.map((item) => {
                const isActive = pathname === item.href || pathname.startsWith(item.href + '/')
                return (
                  <Link key={item.key} href={item.href} style={linkStyle(isActive, true)}>
                    {item.label}
                  </Link>
                )
              })}
            </>
          )}

        </nav>

        {/* Footer */}
        <div style={{ padding: '16px 12px', borderTop: '1px solid rgba(255,255,255,0.08)' }}>
          <div
            style={{
              padding: '12px 14px',
              borderRadius: '10px',
              background: 'rgba(255,255,255,0.04)',
              marginBottom: '8px',
            }}
          >
            <p style={{ color: '#e2e8f0', fontSize: '13px', fontWeight: 600, margin: '0 0 2px' }}>
              {adminName}
            </p>
            <p style={{ color: '#64748b', fontSize: '11px', margin: 0 }}>
              {roleLabel(adminRole)}
            </p>
          </div>
          <button
            id="hotel-admin-logout-btn"
            onClick={handleLogout}
            disabled={loggingOut}
            style={{
              width: '100%',
              background: 'rgba(239,68,68,0.1)',
              border: '1px solid rgba(239,68,68,0.2)',
              borderRadius: '10px',
              padding: '10px 14px',
              color: '#f87171',
              fontSize: '13px',
              cursor: loggingOut ? 'not-allowed' : 'pointer',
              textAlign: 'left',
              transition: 'all 0.15s',
            }}
          >
            🚪 {loggingOut ? 'Çıkış yapılıyor...' : 'Çıkış Yap'}
          </button>
        </div>
      </aside>

      {/* Main */}
      <main style={{ flex: 1, overflow: 'auto', background: 'transparent', paddingTop: isMobile ? 64 : 0 }}>{children}</main>
    </div>
  )
}
