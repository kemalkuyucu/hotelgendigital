/**
 * Allergen state reset - Demo Hotel tenant DB (REST API via fetch)
 * Target: telegram_chat_id = 758605940 / platform_user_id = 758605940
 */

const DEMO_SUPABASE_URL = 'https://rvsyvegfeywzqbqljlij.supabase.co';
const DEMO_SERVICE_ROLE_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJ2c3l2ZWdmZXl3enFicWxqbGlqIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc3Nzk3MzQ2OCwiZXhwIjoyMDkzNTQ5NDY4fQ.T1NtIugkuxcX0sLcw3LVDavJHLhdXzjwR4FO2oDiEio';

const TELEGRAM_CHAT_ID = '758605940';

const headers = {
  'apikey': DEMO_SERVICE_ROLE_KEY,
  'Authorization': `Bearer ${DEMO_SERVICE_ROLE_KEY}`,
  'Content-Type': 'application/json',
  'Prefer': 'return=representation',
};

const REST = `${DEMO_SUPABASE_URL}/rest/v1`;

async function apiFetch(method, table, query = '', body = null) {
  const url = `${REST}/${table}${query ? '?' + query : ''}`;
  const opts = { method, headers };
  if (body) opts.body = JSON.stringify(body);
  const res = await fetch(url, opts);
  const text = await res.text();
  let data;
  try { data = JSON.parse(text); } catch { data = text; }
  if (!res.ok) throw new Error(`${method} ${table}: HTTP ${res.status} => ${text}`);
  return data;
}

async function main() {
  console.log('=== ALLERGEN STATE RESET ===');
  console.log(`Target: telegram_chat_id/platform_user_id = ${TELEGRAM_CHAT_ID}`);
  console.log('');

  // ── 1. conversations – mevcut durumu gör ───────────────────────────
  console.log('1. conversations tablosu sıfırlanıyor...');

  const convBefore = await apiFetch('GET', 'conversations',
    `telegram_chat_id=eq.${TELEGRAM_CHAT_ID}&select=id,allergen_asked,allergen_pending,allergen_verify_pending,allergen_verify_pending_at,allergen_verify_attempts,verification_pending_intent,verification_attempts,verified_at,verified_inhouse_guest_id`
  );
  console.log('  Mevcut durum:', JSON.stringify(convBefore, null, 2));

  const convUpdated = await apiFetch('PATCH', 'conversations',
    `telegram_chat_id=eq.${TELEGRAM_CHAT_ID}&select=allergen_asked,allergen_pending,allergen_verify_pending,allergen_verify_pending_at,allergen_verify_attempts,verification_pending_intent,verification_attempts,verified_at,verified_inhouse_guest_id`,
    {
      allergen_asked: false,
      allergen_pending: false,
      allergen_verify_pending: false,
      allergen_verify_pending_at: null,
      allergen_verify_attempts: 0,
      verification_pending_intent: null,
      verification_attempts: 0,
      verified_at: null,
      verified_inhouse_guest_id: null,
    }
  );
  console.log('  ✅ Güncellendi. Satır:', Array.isArray(convUpdated) ? convUpdated.length : 1);
  console.log('  Güncel değerler:', JSON.stringify(convUpdated, null, 2));

  // ── 2. guest_allergens sil ─────────────────────────────────────────
  console.log('\n2. guest_allergens siliniyor...');

  const allergensDeleted = await apiFetch('DELETE', 'guest_allergens',
    `platform_user_id=eq.${TELEGRAM_CHAT_ID}&select=id`
  );
  console.log(`  ✅ Silinen: ${Array.isArray(allergensDeleted) ? allergensDeleted.length : 0} kayıt`);

  const allergensCheck = await apiFetch('GET', 'guest_allergens',
    `platform_user_id=eq.${TELEGRAM_CHAT_ID}&select=id`
  );
  console.log(`  Kalan: ${Array.isArray(allergensCheck) ? allergensCheck.length : 0} kayıt (0 olmalı)`);

  // ── 3. allergen_notification_log sil ──────────────────────────────
  console.log('\n3. allergen_notification_log siliniyor (tüm kayıtlar)...');

  const logDeleted = await apiFetch('DELETE', 'allergen_notification_log',
    `id=gte.00000000-0000-0000-0000-000000000000&select=id`
  );
  console.log(`  ✅ Silinen: ${Array.isArray(logDeleted) ? logDeleted.length : 0} kayıt`);

  const logCheck = await apiFetch('GET', 'allergen_notification_log',
    `select=id`
  );
  console.log(`  Kalan: ${Array.isArray(logCheck) ? logCheck.length : 0} kayıt (0 olmalı)`);

  // ── ÖZET ──────────────────────────────────────────────────────────
  console.log('\n══════════════════════════════════════');
  console.log('ÖZET RAPOR');
  console.log('══════════════════════════════════════');

  const finalConv = await apiFetch('GET', 'conversations',
    `telegram_chat_id=eq.${TELEGRAM_CHAT_ID}&select=allergen_asked,allergen_pending,allergen_verify_pending,allergen_verify_pending_at,allergen_verify_attempts,verification_pending_intent,verification_attempts,verified_at,verified_inhouse_guest_id`
  );
  const gaCount = await apiFetch('GET', 'guest_allergens',
    `platform_user_id=eq.${TELEGRAM_CHAT_ID}&select=id`
  );
  const logCount = await apiFetch('GET', 'allergen_notification_log', `select=id`);

  console.log('conversations (chat_id=758605940):');
  console.log(JSON.stringify(finalConv?.[0] ?? finalConv, null, 2));
  console.log(`\nguest_allergens (platform_user_id=758605940): ${Array.isArray(gaCount) ? gaCount.length : 0} kayıt`);
  console.log(`allergen_notification_log (toplam): ${Array.isArray(logCount) ? logCount.length : 0} kayıt`);
  console.log('\n✅ Ortam hazır. Test başlatılabilir!');
}

main().catch(e => {
  console.error('HATA:', e.message);
  process.exit(1);
});
