const https = require('https');

const SUPABASE_URL = 'https://rvsyvegfeywzqbqljlij.supabase.co';
const SERVICE_ROLE_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJ2c3l2ZWdmZXl3enFicWxqbGlqIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc3Nzk3MzQ2OCwiZXhwIjoyMDkzNTQ5NDY4fQ.T1NtIugkuxcX0sLcw3LVDavJHLhdXzjwR4FO2oDiEio';

function request(path) {
  return new Promise((resolve, reject) => {
    const url = new URL(SUPABASE_URL + path);
    const opts = {
      hostname: url.hostname,
      path: url.pathname + url.search,
      method: 'GET',
      headers: {
        'apikey': SERVICE_ROLE_KEY,
        'Authorization': 'Bearer ' + SERVICE_ROLE_KEY,
        'Content-Type': 'application/json',
      }
    };
    const req = https.request(opts, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => resolve(JSON.parse(data)));
    });
    req.on('error', reject);
    req.end();
  });
}

async function main() {
  // 1. conversations - en son güncellenen kayıt
  const conv = await request('/rest/v1/conversations?select=allergen_asked,allergen_pending,verification_pending_intent,verified_at&order=updated_at.desc&limit=1');
  console.log('=== conversations (en son updated_at) ===');
  console.table(conv);

  // 2. guest_allergens - en son 5 kayıt
  const ga = await request('/rest/v1/guest_allergens?select=status,allergen_text,asked_at,platform_user_id&order=created_at.desc&limit=5');
  console.log('=== guest_allergens (en son 5 kayıt) ===');
  if (ga.length === 0) {
    console.log('(kayıt yok)');
  } else {
    console.table(ga);
  }
}

main().catch(e => console.error(e.message));
