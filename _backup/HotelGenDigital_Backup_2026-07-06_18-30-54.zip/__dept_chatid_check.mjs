import { readFileSync } from 'fs';
const env = readFileSync('.env.local', 'utf8');
const getEnv = (key) => {
  const lines = env.split('\n');
  for (const line of lines) {
    if (line.startsWith(key + '=')) return line.slice(key.length + 1).replace(/^["']|["']\s*$/g, '').trim();
  }
  return null;
};
const url = getEnv('DEMO_HOTEL_SUPABASE_URL');
const svcKey = getEnv('DEMO_HOTEL_SUPABASE_SERVICE_ROLE_KEY');

// Tüm departments - code ve telegram_chat_id
const r1 = await fetch(`${url}/rest/v1/departments?select=code,display_name,telegram_chat_id`, {
  headers: { 'apikey': svcKey, 'Authorization': `Bearer ${svcKey}`, 'Accept': 'application/json' }
});
const all = await r1.json();
console.log('=== TÜM DEPARTMENTS telegram_chat_id ===');
for (const d of all) {
  console.log(`  [${d.code}] "${d.display_name}" → telegram_chat_id = ${d.telegram_chat_id ?? 'NULL'}`);
}
