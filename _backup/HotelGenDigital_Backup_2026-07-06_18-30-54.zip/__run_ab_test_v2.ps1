#!/usr/bin/env pwsh

$SECRET = "ee7f3ad0a5e469c5fccae35076767a5e96ec33f08d9a7e80ea4c982062d9b70d"
$URL = "https://hotelgen-v2.vercel.app/api/webhooks/telegram/green-park-otel-demo"
$SUPABASE_URL = "https://rvsyvegfeywzqbqljlij.supabase.co"
$SUPABASE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJ2c3l2ZWdmZXl3enFicWxqbGlqIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc3Nzk3MzQ2OCwiZXhwIjoyMDkzNTQ5NDY4fQ.T1NtIugkuxcX0sLcw3LVDavJHLhdXzjwR4FO2oDiEio"

# Ozgur Ozen - oda 102 - inhouse_guests_v2 id
$OZGUR_V2_ID = "5b047515-419c-4105-896f-aa23d56c29da"
$OZGUR_CONV_ID = "0b389003-c215-4c40-9226-be50eaafc668"
$OZGUR_TG_ID = 758605940

function Invoke-Webhook($body) {
    $response = Invoke-RestMethod -Uri $URL -Method POST `
        -ContentType "application/json" `
        -Headers @{ "x-telegram-bot-api-secret-token" = $SECRET } `
        -Body ($body | ConvertTo-Json -Depth 10) `
        -ErrorAction SilentlyContinue
    return $response
}

function Invoke-Supa($table, $method, $filters, $body) {
    $uri = "$SUPABASE_URL/rest/v1/$table" + $filters
    $params = @{
        Uri     = $uri
        Method  = $method
        Headers = @{
            "apikey"        = $SUPABASE_KEY
            "Authorization" = "Bearer $SUPABASE_KEY"
            "Content-Type"  = "application/json"
            "Prefer"        = "return=representation"
        }
    }
    if ($body) { $params["Body"] = ($body | ConvertTo-Json -Depth 10) }
    try {
        return Invoke-RestMethod @params
    } catch {
        Write-Host "  [Supa error] $($_.Exception.Message)" -ForegroundColor Red
        return $null
    }
}

# ============================================================
# SENARYO B SETUP: Ozgur'un conversation'ina verified_inhouse_guest_id ATA
# Bu, "klima calismiyor 102 Ozgur Ozen" ile dogrulama yapilmis durumunu simule eder
# ============================================================

Write-Host "=== SENARYO B SETUP ===" -ForegroundColor Magenta
Write-Host "Ozgur conversation'ina verified_inhouse_guest_id ataniyor..." -ForegroundColor Yellow
Write-Host "  conversation_id: $OZGUR_CONV_ID"
Write-Host "  verified_inhouse_guest_id: $OZGUR_V2_ID (Ozgur Ozen, oda 102)"

$updateBody = @{
    verified_inhouse_guest_id  = $OZGUR_V2_ID
    verified_at                = (Get-Date).ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ss.fffZ")
    verification_pending_intent = $null
    verification_attempts      = 0
    pending_request_text       = "klima calismiyor"
}

$updateResult = Invoke-Supa "conversations" "PATCH" "?id=eq.$OZGUR_CONV_ID" $updateBody
Write-Host "Update sonucu: $($updateResult | ConvertTo-Json -Compress)" -ForegroundColor Green

Start-Sleep -Seconds 2

# Verify DB state
$convCheck = Invoke-Supa "conversations" "GET" "?id=eq.$OZGUR_CONV_ID&select=id,verified_inhouse_guest_id,verified_at,pending_request_text" $null
Write-Host "DB dogrulama: $($convCheck | ConvertTo-Json -Compress)" -ForegroundColor Yellow

# ============================================================
# SENARYO A - DOGRULANMAMIS KULLANICI (9999001)
# ============================================================
Write-Host "`n========================================" -ForegroundColor Cyan
Write-Host "SENARYO A - DOGRULANMAMIS KULLANICI (9999001)" -ForegroundColor Cyan
Write-Host "Mesaj: 'yakinda eczane var mi'" -ForegroundColor Cyan
Write-Host "========================================`n" -ForegroundColor Cyan

# Onceki sayilari kaydet
$slaBefore_A = (Invoke-Supa "sla_events" "GET" "?select=id&order=created_at.desc" $null).Count
Write-Host "sla_events onceki sayi: $slaBefore_A" -ForegroundColor Yellow

$bodyA = @{
    update_id = 300001
    message = @{
        message_id = 101
        from = @{ id = 9999001; is_bot = $false; first_name = "TestA"; language_code = "tr" }
        chat = @{ id = 9999001; type = "private" }
        date = [int][DateTimeOffset]::UtcNow.ToUnixTimeSeconds()
        text = "yakinda eczane var mi"
    }
}

Write-Host "Webhook gonderiliyor (A)..." -ForegroundColor Green
$resultA = Invoke-Webhook $bodyA
Write-Host "Yanit A: $($resultA | ConvertTo-Json -Compress)" -ForegroundColor Green

Start-Sleep -Seconds 8

$slaAfter_A = Invoke-Supa "sla_events" "GET" "?select=id,department_code,request_text,room_number,guest_full_name,created_at&order=created_at.desc&limit=3" $null
$newSlaA = $slaAfter_A.Count - $slaBefore_A

Write-Host "`n--- SENARYO A SONUCU ---" -ForegroundColor Cyan
Write-Host "sla_events oncesi: $slaBefore_A" -ForegroundColor White
Write-Host "sla_events sonrasi: $($slaAfter_A.Count)" -ForegroundColor White  
Write-Host "YENI sla_events (FORWARD SAYISI): $newSlaA" -ForegroundColor $(if ($newSlaA -gt 0) { "Red" } else { "Green" })

# Son sla_event'i goster
if ($slaAfter_A.Count -gt 0) {
    $latest = $slaAfter_A | Sort-Object created_at -Descending | Select-Object -First 1
    Write-Host "En son sla_event: dept=$($latest.department_code) room=$($latest.room_number) request='$($latest.request_text)'" -ForegroundColor White
}

Start-Sleep -Seconds 3

# ============================================================
# SENARYO B - DOGRULANMIS KULLANICI (Ozgur, 758605940)
# persistentVerifiedGuest DOLU
# ============================================================
Write-Host "`n========================================" -ForegroundColor Magenta
Write-Host "SENARYO B - DOGRULANMIS KULLANICI (Ozgur, 758605940)" -ForegroundColor Magenta
Write-Host "persistentVerifiedGuest DOLU (DB'de verified_inhouse_guest_id set)" -ForegroundColor Magenta
Write-Host "Mesaj: 'yakinda eczane var mi'" -ForegroundColor Magenta
Write-Host "========================================`n" -ForegroundColor Magenta

# Onceki sayilari kaydet
$slaBefore_B = (Invoke-Supa "sla_events" "GET" "?select=id&order=created_at.desc" $null).Count
Write-Host "sla_events onceki sayi (B): $slaBefore_B" -ForegroundColor Yellow

$bodyB = @{
    update_id = 300010
    message = @{
        message_id = 110
        from = @{ id = $OZGUR_TG_ID; is_bot = $false; first_name = "Ozgur"; language_code = "tr" }
        chat = @{ id = $OZGUR_TG_ID; type = "private" }
        date = [int][DateTimeOffset]::UtcNow.ToUnixTimeSeconds()
        text = "yakinda eczane var mi"
    }
}

Write-Host "Webhook gonderiliyor (B - eczane sorusu)..." -ForegroundColor Green
$resultB = Invoke-Webhook $bodyB
Write-Host "Yanit B: $($resultB | ConvertTo-Json -Compress)" -ForegroundColor Green

Start-Sleep -Seconds 10

$slaAfter_B = Invoke-Supa "sla_events" "GET" "?select=id,department_code,request_text,room_number,guest_full_name,created_at&order=created_at.desc&limit=3" $null
$newSlaB = $slaAfter_B.Count - $slaBefore_B

Write-Host "`n--- SENARYO B SONUCU ---" -ForegroundColor Magenta
Write-Host "sla_events oncesi: $slaBefore_B" -ForegroundColor White
Write-Host "sla_events sonrasi: $($slaAfter_B.Count)" -ForegroundColor White
Write-Host "YENI sla_events (FORWARD SAYISI): $newSlaB" -ForegroundColor $(if ($newSlaB -gt 0) { "Red" } else { "Green" })

if ($slaAfter_B.Count -gt 0) {
    $latestB = $slaAfter_B | Sort-Object created_at -Descending | Select-Object -First 1
    Write-Host "En son sla_event: dept=$($latestB.department_code) room=$($latestB.room_number) guest=$($latestB.guest_full_name) request='$($latestB.request_text)'" -ForegroundColor White
}

# ============================================================
# KARSILASTIRMA OZETI
# ============================================================
Write-Host "`n`n========================================" -ForegroundColor Yellow
Write-Host "FINAL KARSILASTIRMA OZETI" -ForegroundColor Yellow
Write-Host "========================================" -ForegroundColor Yellow
Write-Host "Senaryo A (dogrulanmamis, 9999001) FORWARD: $newSlaA yeni sla_event" -ForegroundColor White
Write-Host "Senaryo B (dogrulanmis, Ozgur 102) FORWARD: $newSlaB yeni sla_event" -ForegroundColor White

if ($newSlaA -eq 0 -and $newSlaB -gt 0) {
    Write-Host "`n*** HIPOTEZ DOGRULANDI ***" -ForegroundColor Red
    Write-Host "A'da forward YOK, B'de forward VAR." -ForegroundColor Red
    Write-Host "persistentVerifiedGuest dolu oldugunda bilgi sorusu (eczane) yine de forward ediliyor!" -ForegroundColor Red
    Write-Host "Bug: L2010 if(persistentVerifiedGuest) blogu skipForward'i kontrol etmiyor!" -ForegroundColor Red
} elseif ($newSlaA -eq 0 -and $newSlaB -eq 0) {
    Write-Host "`nHer ikisinde de forward YOK — hipotez reddedildi." -ForegroundColor Green
    Write-Host "(Fix duzgun calistiyor veya AI 'bilgi sorusu' olarak isInfoOnlyQuery=true yakalamis)" -ForegroundColor Green
} elseif ($newSlaA -gt 0 -and $newSlaB -gt 0) {
    Write-Host "`nHer ikisinde de forward VAR — genel bug, sadece persistentVerified ile ilgili degil." -ForegroundColor Red
} else {
    Write-Host "`nBeklenmedik durum: A'da var, B'de yok." -ForegroundColor Yellow
}
