/**
 * ALERJEN — Conversation State Diagnostic
 * telegram_chat_id=758605940 için state + akış analizi
 */
const https = require('https');

const SUPABASE_URL = 'https://rvsyvegfeywzqbqljlij.supabase.co';
const SERVICE_KEY  = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJ2c3l2ZWdmZXl3enFicWxqbGlqIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc3Nzk3MzQ2OCwiZXhwIjoyMDkzNTQ5NDY4fQ.T1NtIugkuxcX0sLcw3LVDavJHLhdXzjwR4FO2oDiEio';

const TELEGRAM_CHAT_ID = '758605940';

function get(path) {
  return new Promise((resolve, reject) => {
    const url = new URL(SUPABASE_URL + path);
    const opts = {
      hostname: url.hostname,
      path: url.pathname + url.search,
      method: 'GET',
      headers: {
        'apikey': SERVICE_KEY,
        'Authorization': 'Bearer ' + SERVICE_KEY,
        'Content-Type': 'application/json',
      }
    };
    const r = https.request(opts, (res) => {
      let data = '';
      res.on('data', c => data += c);
      res.on('end', () => {
        try { resolve(JSON.parse(data)); }
        catch { resolve({ _raw: data }); }
      });
    });
    r.on('error', reject);
    r.end();
  });
}

// isVerificationValid: verified_at'dan 24 saat geçmediyse true
function isVerificationValid(verifiedAt) {
  if (!verifiedAt) return false;
  const dt = new Date(verifiedAt);
  const now = new Date();
  const diffHours = (now - dt) / (1000 * 60 * 60);
  return diffHours < 24;
}

async function main() {

  // ─── 1. Conversation state ───────────────────────────────────────────────
  console.log('\n══════════════════════════════════════════════════════════════');
  console.log('  CONVERSATION STATE — telegram_chat_id=' + TELEGRAM_CHAT_ID);
  console.log('══════════════════════════════════════════════════════════════');

  const convs = await get(
    '/rest/v1/conversations' +
    '?select=id,telegram_chat_id,allergen_asked,allergen_pending,verification_pending_intent,verified_at,verified_inhouse_guest_id,inhouse_match_guest_id,verification_attempts,updated_at' +
    '&telegram_chat_id=eq.' + TELEGRAM_CHAT_ID +
    '&order=updated_at.desc&limit=1'
  );

  if (!Array.isArray(convs) || convs.length === 0) {
    console.log('⚠️  Bu telegram_chat_id için conversations kaydı BULUNAMADI.');
    if (convs && convs.message) console.log('   Hata:', convs.message);
    return;
  }

  const conv = convs[0];

  console.log('');
  console.log('  conversation_id            :', conv.id);
  console.log('  allergen_asked             :', conv.allergen_asked);
  console.log('  allergen_pending           :', conv.allergen_pending);
  console.log('  verification_pending_intent:', conv.verification_pending_intent);
  console.log('  verified_at                :', conv.verified_at);
  console.log('  verified_inhouse_guest_id  :', conv.verified_inhouse_guest_id);
  console.log('  inhouse_match_guest_id     :', conv.inhouse_match_guest_id);
  console.log('  verification_attempts      :', conv.verification_attempts);
  console.log('  updated_at                 :', conv.updated_at);
  console.log('');

  // ─── 2. canAskAllergen Analizi ──────────────────────────────────────────
  console.log('══════════════════════════════════════════════════════════════');
  console.log('  canAskAllergen KOMPONENTLERİ (kod simülasyonu)');
  console.log('══════════════════════════════════════════════════════════════');

  const allergenAsked    = conv.allergen_asked;
  const allergenPending  = conv.allergen_pending;
  const verPendingIntent = conv.verification_pending_intent;
  const verifiedAt       = conv.verified_at;
  const verifiedGuestId  = conv.verified_inhouse_guest_id;

  const verValidNow      = isVerificationValid(verifiedAt);
  const verificationIsActive = !!verPendingIntent && !verValidNow;

  console.log('');
  console.log('  isFbIntent (varsayım: "Restoran saati" → AI fb döndü)  : TRUE (hipotetik)');
  console.log('  !allergen_asked                                         :', !allergenAsked, '  (allergen_asked=', allergenAsked, ')');
  console.log('  !allergen_pending                                       :', !allergenPending, '  (allergen_pending=', allergenPending, ')');
  console.log('  !verificationIsActive                                   :', !verificationIsActive);
  console.log('    ↳ verification_pending_intent                        :', verPendingIntent ?? '(null)');
  console.log('    ↳ verified_at                                        :', verifiedAt ?? '(null)');
  console.log('    ↳ isVerificationValid(verified_at)                   :', verValidNow, '  (24 saat geçti mi?)');
  console.log('    ↳ verificationIsActive = !!intent && !valid          :', verificationIsActive);
  console.log('');

  // canAskAllergen = isFbIntent && !allergen_asked && !allergen_pending && !verificationIsActive
  const canAskAllergen = !allergenAsked && !allergenPending && !verificationIsActive;
  // (isFbIntent=true varsayımıyla)

  console.log('  ─────────────────────────────────────────────────────────');
  console.log('  canAskAllergen (isFbIntent=TRUE varsayımıyla) :', canAskAllergen);
  console.log('  ─────────────────────────────────────────────────────────');
  console.log('');

  // ─── 3. Neden alerji atlandi? ────────────────────────────────────────────
  console.log('══════════════════════════════════════════════════════════════');
  console.log('  NEDEN ALERJİ ATLANINIP DOĞRULAMA GATE DEVREYEGİRDİ?');
  console.log('══════════════════════════════════════════════════════════════');
  console.log('');

  if (verificationIsActive) {
    console.log('🚨 NEDEN: verificationIsActive=TRUE olduğu için canAskAllergen=FALSE');
    console.log('');
    console.log('  verification_pending_intent =', verPendingIntent);
    console.log('  Bu intent var + verified_at geçersiz → bot alerji sormak yerine');
    console.log('  doğrudan verification gate\'e düştü → "oda no ver" dedi.');
    console.log('');
    console.log('  Verification gate koşulu (route.ts ~L1659-1670):');
    console.log('    conversation.verification_pending_intent === "allergen_room_verify"');
    console.log('    VE !isVerificationValid(verified_at)');
    console.log('  → Bu koşul TRUE → handleVerificationFlow çağrıldı → oda no istendi.');
    console.log('');
    if (verPendingIntent === 'allergen_room_verify') {
      console.log('  ⚠️  Intent "allergen_room_verify": Daha ÖNCEKI bir alerji akışında');
      console.log('     allergen_pending=false + allergen_asked=true YAPILMIŞ,');
      console.log('     oda no bekleniyor durumuna girilmiş ama doğrulama tamamlanmamış.');
      console.log('     Yeni "Restoran saati" mesajı geldiğinde bu pending intent sıfırlanmamış.');
    } else {
      console.log('  Intent:', verPendingIntent, '— FB dışı bir intent bekleniyordu.');
    }
  } else if (allergenAsked) {
    console.log('ℹ️  NEDEN: allergen_asked=TRUE → Alerji zaten daha önce sorulmuş.');
    console.log('  canAskAllergen=FALSE çünkü allergen_asked=true.');
    console.log('');
    if (verifiedGuestId) {
      console.log('  verified_inhouse_guest_id var → persistent guest aktif.');
      console.log('  Verification gate\'e girmedi (persistentVerifiedGuest set edildi).');
      console.log('  Bot direkt yanıt verdi veya forward yaptı.');
      console.log('  "Oda no ver" mesajı BU sefer değil, önceki turda sorulmuştu.');
      console.log('');
      console.log('  Ama kullanıcı "101 Kemal Kuyucu" yazdığında re-verify bloğu devreye girdi:');
      console.log('    currentVerifiedGuest var && aiShouldForward → parseVerificationInput çalıştı');
      console.log('    → "101 Kemal Kuyucu" parse edildi → farklı oda/soyad? → verifyGuest çağrıldı');
      console.log('    → eşleşmedi → "eşleşmedi" mesajı döndü (re-verify failure path)');
    } else {
      console.log('  verified_inhouse_guest_id yok → verification gate devreye girdi.');
    }
  } else if (allergenPending) {
    console.log('ℹ️  NEDEN: allergen_pending=TRUE → Alerji short-circuit aktif olmalıydı.');
    console.log('  Bu durumda allergen SC kod bloğu çalışmalı ve "Restoran saati" yakalanmalıydı.');
    console.log('  SC çalışmadıysa → allergen_status=pending ama SC koşulunu kaçırdı demektir.');
  } else {
    console.log('🤔 canAskAllergen koşulları SAĞLANMIŞ görünüyor.');
    console.log('  Sorun isFbIntent\'te olabilir: AI "Restoran saati"yi fb classify etmedi,');
    console.log('  farklı bir intent döndü → isFbIntent=FALSE → canAskAllergen=FALSE.');
    console.log('  Önerim: ai_intents tablosunu kontrol et.');
  }

  // ─── 4. Son 6 bot_messages ───────────────────────────────────────────────
  console.log('\n══════════════════════════════════════════════════════════════');
  console.log('  SON 6 BOT_MESSAGES (kronolojik)');
  console.log('══════════════════════════════════════════════════════════════');

  const msgs = await get(
    '/rest/v1/bot_messages' +
    '?select=direction,text,created_at' +
    '&conversation_id=eq.' + conv.id +
    '&order=created_at.desc&limit=6'
  );

  if (!Array.isArray(msgs) || msgs.length === 0) {
    console.log('(mesaj yok)');
  } else {
    [...msgs].reverse().forEach((m, i) => {
      const dir = m.direction === 'inbound' ? '👤 Misafir' : '🤖 Bot    ';
      const ts = new Date(m.created_at).toLocaleString('tr-TR', { timeZone: 'Europe/Istanbul' });
      const txt = String(m.text ?? '').slice(0, 110);
      console.log(`  [${i+1}] ${dir} (${ts})`);
      console.log(`       "${txt}"`);
    });
  }

  // ─── 5. Son ai_intent kaydı ──────────────────────────────────────────────
  console.log('\n══════════════════════════════════════════════════════════════');
  console.log('  SON 3 AI_INTENT (ne intent döndü?)');
  console.log('══════════════════════════════════════════════════════════════');

  const intents = await get(
    '/rest/v1/ai_intents' +
    '?select=classified_department,ai_response,created_at' +
    '&conversation_id=eq.' + conv.id +
    '&order=created_at.desc&limit=3'
  );

  if (!Array.isArray(intents) || intents.length === 0) {
    console.log('(ai_intents kaydı yok)');
  } else {
    [...intents].reverse().forEach((r, i) => {
      const ts = new Date(r.created_at).toLocaleString('tr-TR', { timeZone: 'Europe/Istanbul' });
      console.log(`  [${i+1}] intent=${r.classified_department}  (${ts})`);
      console.log(`       AI yanıt: "${String(r.ai_response ?? '').slice(0, 100)}"`);
    });
  }

  console.log('\n════ TEŞHİS TAMAMLANDI ════\n');
}

main().catch(e => console.error('SCRIPT HATA:', e.message));
