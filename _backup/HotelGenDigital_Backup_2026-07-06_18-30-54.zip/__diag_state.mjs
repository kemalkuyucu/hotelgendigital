import { createClient } from '@supabase/supabase-js';

const DEMO_URL = 'https://rvsyvegfeywzqbqljlij.supabase.co';
const DEMO_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJ2c3l2ZWdmZXl3enFicWxqbGlqIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc3Nzk3MzQ2OCwiZXhwIjoyMDkzNTQ5NDY4fQ.T1NtIugkuxcX0sLcw3LVDavJHLhdXzjwR4FO2oDiEio';

const supa = createClient(DEMO_URL, DEMO_KEY, {
  realtime: { enabled: false },
  global: { fetch: globalThis.fetch },
});

const TELEGRAM_CHAT_ID = 758605940;

// 1) conversations tablosundan state çek
const { data: conv, error: convErr } = await supa
  .from('conversations')
  .select(`
    id,
    telegram_chat_id,
    allergen_asked,
    allergen_pending,
    verification_pending_intent,
    verified_at,
    verified_inhouse_guest_id,
    inhouse_match_guest_id,
    verification_attempts,
    updated_at
  `)
  .eq('telegram_chat_id', String(TELEGRAM_CHAT_ID))
  .order('updated_at', { ascending: false })
  .limit(1)
  .maybeSingle();

if (convErr) {
  console.error('conversations ERROR:', convErr.message);
} else if (!conv) {
  console.log('⚠️  Bu telegram_chat_id için conversations kaydı bulunamadı.');
} else {
  console.log('\n══════════════════════════════════════════════');
  console.log('  CONVERSATION STATE — telegram_chat_id=' + TELEGRAM_CHAT_ID);
  console.log('══════════════════════════════════════════════');
  console.log('  conversation_id          :', conv.id);
  console.log('  allergen_asked           :', conv.allergen_asked, '  ← alerji sorusu soruldu mu?');
  console.log('  allergen_pending         :', conv.allergen_pending, '  ← alerji cevabı bekleniyor mu?');
  console.log('  verification_pending_intent:', conv.verification_pending_intent, '  ← bekleyen doğrulama intent');
  console.log('  verified_at              :', conv.verified_at);
  console.log('  verified_inhouse_guest_id:', conv.verified_inhouse_guest_id);
  console.log('  inhouse_match_guest_id   :', conv.inhouse_match_guest_id);
  console.log('  verification_attempts    :', conv.verification_attempts);
  console.log('  updated_at               :', conv.updated_at);
  console.log('══════════════════════════════════════════════\n');

  // canAskAllergen koşullarını simüle et
  const allergenAsked   = conv.allergen_asked;
  const allergenPending = conv.allergen_pending;
  const verificationPendingIntent = conv.verification_pending_intent;
  const verifiedAt = conv.verified_at;

  // isVerificationValid: verified_at varsa 24 saat geçmemiş mi?
  function isVerificationValid(verifiedAt) {
    if (!verifiedAt) return false;
    const dt = new Date(verifiedAt);
    const now = new Date();
    const diffMs = now.getTime() - dt.getTime();
    const diffHours = diffMs / (1000 * 60 * 60);
    return diffHours < 24;
  }

  const verificationIsActive =
    !!verificationPendingIntent && !isVerificationValid(verifiedAt);

  console.log('🔍 canAskAllergen KOMPONENTLERİ (simülasyon):');
  console.log('  isFbIntent               : [F&B sorusu ise TRUE — "Restoran saati" → AI fb intent verir]');
  console.log('  allergen_asked           :', allergenAsked, ' → !allergen_asked =', !allergenAsked);
  console.log('  allergen_pending         :', allergenPending, ' → !allergen_pending =', !allergenPending);
  console.log('  verificationIsActive     :', verificationIsActive, ' → !verificationIsActive =', !verificationIsActive);
  console.log('    ↳ verification_pending_intent:', verificationPendingIntent, '  verified_at:', verifiedAt);
  console.log('');

  const canAskAllergenWouldBeTrue = !allergenAsked && !allergenPending && !verificationIsActive;
  console.log('  canAskAllergen (isFbIntent=true varsayımıyla):', canAskAllergenWouldBeTrue);
  console.log('');

  if (verificationIsActive) {
    console.log('🚨 SORUN TESPİT EDİLDİ:');
    console.log('  verificationIsActive=TRUE olduğu için canAskAllergen=FALSE oldu!');
    console.log('  Yani verification gate ÖNCE devreye girdi.');
    console.log('  Bot alerji sormak yerine doğrudan oda no sordu.');
    console.log('');
    console.log('  verification_pending_intent =', verificationPendingIntent);
    console.log('  Bu intent temizlenmediği sürece bot hep oda no soracak.');
  } else if (allergenAsked) {
    console.log('ℹ️  allergen_asked=TRUE: Alerji zaten daha önce sorulmuş, bu sefer sorulmaz.');
    console.log('  Ama canAskAllergen=FALSE olur — bu sefer FB sorusunda alerji eklemez.');
    console.log('  Verification gate devreye girebilir.');
    if (conv.verified_inhouse_guest_id) {
      console.log('  verified_inhouse_guest_id var: persistent guest → verification gate atlanır.');
      console.log('  O yüzden bot doğrudan yanıt verdi veya forward etti.');
    }
  } else {
    console.log('✅ Görünüşe göre canAskAllergen koşulları sağlanıyor. Sorun isFbIntent\'te olabilir.');
  }
}

// 2) Son bot_messages — ne konuşuldu?
console.log('\n─── Son 5 bot_messages ───────────────────────────────');
const { data: msgs } = await supa
  .from('bot_messages')
  .select('direction, text, created_at')
  .eq('conversation_id', conv?.id ?? '')
  .order('created_at', { ascending: false })
  .limit(5);

(msgs ?? []).reverse().forEach((m, i) => {
  const dir = m.direction === 'inbound' ? '👤 Misafir' : '🤖 Bot    ';
  const ts = new Date(m.created_at).toLocaleTimeString('tr-TR', { timeZone: 'Europe/Istanbul' });
  console.log(`  [${i+1}] ${dir} (${ts}): ${String(m.text).slice(0, 100)}`);
});
console.log('──────────────────────────────────────────────────────\n');
