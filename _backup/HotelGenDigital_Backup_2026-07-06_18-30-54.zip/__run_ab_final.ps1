#!/usr/bin/env pwsh

$SUPABASE_URL = 'https://rvsyvegfeywzqbqljlij.supabase.co'
$SUPABASE_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJ2c3l2ZWdmZXl3enFicWxqbGlqIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc3Nzk3MzQ2OCwiZXhwIjoyMDkzNTQ5NDY4fQ.T1NtIugkuxcX0sLcw3LVDavJHLhdXzjwR4FO2oDiEio'
$OZGUR_CONV_ID = '0b389003-c215-4c40-9226-be50eaafc668'
$OZGUR_V2_ID = '5b047515-419c-4105-896f-aa23d56c29da'
$SECRET = 'ee7f3ad0a5e469c5fccae35076767a5e96ec33f08d9a7e80ea4c982062d9b70d'
$URL = 'https://hotelgen-v2.vercel.app/api/webhooks/telegram/green-park-otel-demo'
$OZGUR_TG_ID = 758605940

$supaHeaders = @{
    'apikey'        = $SUPABASE_KEY
    'Authorization' = "Bearer $SUPABASE_KEY"
    'Content-Type'  = 'application/json'
}

# Test 1: Sadece basit alan patch
$testBody = '{"verified_at":"2026-05-30T07:00:00.000Z"}'
Write-Host "Test 1 - verified_at patch..."
try {
    $r = Invoke-RestMethod -Uri "$SUPABASE_URL/rest/v1/conversations?id=eq.$OZGUR_CONV_ID" `
        -Method PATCH `
        -Headers $supaHeaders `
        -Body $testBody
    Write-Host "Test 1 basarili"
} catch {
    Write-Host "Test 1 HATA: $($_.Exception.Message)"
    try {
        $errStream = $_.Exception.Response.GetResponseStream()
        $reader = New-Object System.IO.StreamReader($errStream)
        Write-Host "Response: $($reader.ReadToEnd())"
    } catch {}
}

# Test 2: verified_inhouse_guest_id ayarla
$testBody2 = "{`"verified_inhouse_guest_id`":`"$OZGUR_V2_ID`",`"verified_at`":`"2026-05-30T07:00:00.000Z`",`"verification_attempts`":0}"
Write-Host "Test 2 - verified_inhouse_guest_id patch..."
try {
    $r2 = Invoke-RestMethod -Uri "$SUPABASE_URL/rest/v1/conversations?id=eq.$OZGUR_CONV_ID" `
        -Method PATCH `
        -Headers $supaHeaders `
        -Body $testBody2
    Write-Host "Test 2 basarili"
} catch {
    Write-Host "Test 2 HATA: $($_.Exception.Message)"
    try {
        $errStream2 = $_.Exception.Response.GetResponseStream()
        $reader2 = New-Object System.IO.StreamReader($errStream2)
        Write-Host "Response: $($reader2.ReadToEnd())"
    } catch {}
}

# Conversation durumunu kontrol et
$convState = Invoke-RestMethod -Uri "$SUPABASE_URL/rest/v1/conversations?id=eq.$OZGUR_CONV_ID&select=id,verified_inhouse_guest_id,verified_at" -Headers $supaHeaders
Write-Host "Conversation durumu: verified_id=$($convState.verified_inhouse_guest_id) verified_at=$($convState.verified_at)"

# Eger hala null ise, sla_events tablosunu tarih bazli sorgula (son 10 dakika)
$tenMinsAgo = (Get-Date).AddMinutes(-10).ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ssZ")
Write-Host "Son 10 dakika sla_events ($tenMinsAgo sonrasi):"
$recentSla = Invoke-RestMethod -Uri "$SUPABASE_URL/rest/v1/sla_events?select=id,department_code,request_text,room_number,guest_full_name,created_at&created_at=gte.$tenMinsAgo" -Headers $supaHeaders
Write-Host "Bulundu: $($recentSla.Count) kayit"
$recentSla | ForEach-Object { Write-Host "  dept=$($_.department_code) room=$($_.room_number) guest=$($_.guest_full_name) request='$($_.request_text)' at=$($_.created_at)" }

# SENARYO A: Dogrulanmamis kullanici
Write-Host "`n=== SENARYO A: DOGRULANMAMIS (9999001) - eczane sorusu ==="
$ts = [int][DateTimeOffset]::UtcNow.ToUnixTimeSeconds()
$bodyA = "{`"update_id`":500001,`"message`":{`"message_id`":301,`"from`":{`"id`":9999001,`"is_bot`":false,`"first_name`":`"TestA`",`"language_code`":`"tr`"},`"chat`":{`"id`":9999001,`"type`":`"private`"},`"date`":$ts,`"text`":`"yakinda eczane var mi`"}}"
try {
    $rA = Invoke-RestMethod -Uri $URL -Method POST -ContentType 'application/json' -Headers @{ 'x-telegram-bot-api-secret-token' = $SECRET } -Body $bodyA
    Write-Host "A webhook yaniti: $($rA | ConvertTo-Json -Compress)"
} catch {
    Write-Host "A webhook HATA: $($_.Exception.Message)"
}

Start-Sleep -Seconds 8

$tenMinsAgo2 = (Get-Date).AddMinutes(-10).ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ssZ")
$afterA = Invoke-RestMethod -Uri "$SUPABASE_URL/rest/v1/sla_events?select=id,department_code,request_text,room_number,guest_full_name,created_at&created_at=gte.$tenMinsAgo2" -Headers $supaHeaders
Write-Host "SLA events (son 10dk) sonrasi A: $($afterA.Count) kayit"
$afterA | ForEach-Object { Write-Host "  dept=$($_.department_code) room=$($_.room_number) guest=$($_.guest_full_name) request='$($_.request_text)'" }

# SENARYO B: Ozgur'a ait - verified durumu kontrol
Write-Host "`n=== SENARYO B: OZGUR (758605940) - eczane sorusu ==="
Write-Host "Ozgur conversation verified_id: $($convState.verified_inhouse_guest_id)"

$ts2 = [int][DateTimeOffset]::UtcNow.ToUnixTimeSeconds()
$bodyB = "{`"update_id`":500010,`"message`":{`"message_id`":310,`"from`":{`"id`":$OZGUR_TG_ID,`"is_bot`":false,`"first_name`":`"Ozgur`",`"language_code`":`"tr`"},`"chat`":{`"id`":$OZGUR_TG_ID,`"type`":`"private`"},`"date`":$ts2,`"text`":`"yakinda eczane var mi`"}}"
try {
    $rB = Invoke-RestMethod -Uri $URL -Method POST -ContentType 'application/json' -Headers @{ 'x-telegram-bot-api-secret-token' = $SECRET } -Body $bodyB
    Write-Host "B webhook yaniti: $($rB | ConvertTo-Json -Compress)"
} catch {
    Write-Host "B webhook HATA: $($_.Exception.Message)"
}

Start-Sleep -Seconds 10

$tenMinsAgo3 = (Get-Date).AddMinutes(-10).ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ssZ")
$afterB = Invoke-RestMethod -Uri "$SUPABASE_URL/rest/v1/sla_events?select=id,department_code,request_text,room_number,guest_full_name,created_at&created_at=gte.$tenMinsAgo3" -Headers $supaHeaders
Write-Host "SLA events (son 10dk) sonrasi B: $($afterB.Count) kayit"
$afterB | ForEach-Object { Write-Host "  dept=$($_.department_code) room=$($_.room_number) guest=$($_.guest_full_name) request='$($_.request_text)'" }

Write-Host "`n=== KARSILASTIRMA ==="
Write-Host "A sonrasi SLA kayit: $($afterA.Count)"
Write-Host "B sonrasi SLA kayit: $($afterB.Count)"
