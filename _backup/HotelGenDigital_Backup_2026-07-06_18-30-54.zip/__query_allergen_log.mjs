const DEMO_URL = 'https://rvsyvegfeywzqbqljlij.supabase.co';
const DEMO_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJ2c3l2ZWdmZXl3enFicWxqbGlqIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc3Nzk3MzQ2OCwiZXhwIjoyMDkzNTQ5NDY4fQ.T1NtIugkuxcX0sLcw3LVDavJHLhdXzjwR4FO2oDiEio';

async function dbQuery(path, select, rawParams = {}, order = null, limit = null) {
  const url = new URL(`${DEMO_URL}/rest/v1/${path}`);
  url.searchParams.set('select', select);
  for (const [k, v] of Object.entries(rawParams)) {
    url.searchParams.set(k, v);
  }
  if (order) url.searchParams.set('order', order);
  if (limit) url.searchParams.set('limit', String(limit));

  const res = await fetch(url.toString(), {
    headers: {
      'apikey': DEMO_KEY,
      'Authorization': `Bearer ${DEMO_KEY}`,
      'Accept': 'application/json'
    }
  });
  if (!res.ok) {
    const txt = await res.text();
    throw new Error(`HTTP ${res.status}: ${txt}`);
  }
  return res.json();
}

async function main() {
  // 1) guest_allergens SON KAYIT
  const allergens = await dbQuery(
    'guest_allergens',
    'id,room_number,allergen_text,created_at',
    {},
    'created_at.desc',
    1
  );

  console.log('\n=== guest_allergens SON KAYIT ===');
  if (!allergens.length) { console.log('(boş)'); return; }
  const last = allergens[0];
  console.log('id           :', last.id);
  console.log('room_number  :', last.room_number);
  console.log('allergen_text:', last.allergen_text);
  console.log('created_at   :', last.created_at);

  // 2) allergen_notification_log kolonlarını keşfet (1 kayıt al)
  console.log('\n=== allergen_notification_log KOLON KEŞFİ (ilk kayıt) ===');
  try {
    const probe = await dbQuery(
      'allergen_notification_log',
      '*',
      {},
      'created_at.desc',
      1
    );
    if (probe.length) {
      console.log('Mevcut kolonlar:', Object.keys(probe[0]).join(', '));
    } else {
      console.log('Tablo boş.');
    }
  } catch(e) {
    console.log('Hata (kolon keşfi):', e.message);
  }

  // 3) allergen_notification_log SON 20 KAYIT
  console.log('\n=== allergen_notification_log SON 20 KAYIT ===');
  try {
    const allLogs = await dbQuery(
      'allergen_notification_log',
      'recipient_type,staff_full_name,telegram_user_id,status,scenario,error_message,notification_text,created_at',
      {},
      'created_at.desc',
      20
    );
    console.log('Toplam satır:', allLogs.length);
    allLogs.forEach((row, i) => {
      console.log(`\n--- Satır ${i+1} (${row.created_at}) ---`);
      console.log('  recipient_type    :', row.recipient_type);
      console.log('  staff_full_name   :', row.staff_full_name);
      console.log('  telegram_user_id  :', row.telegram_user_id);
      console.log('  status            :', row.status);
      console.log('  scenario          :', row.scenario);
      console.log('  error_message     :', row.error_message);
      const nt = row.notification_text;
      console.log('  notification_text :', nt ? nt.substring(0, 120) + (nt.length > 120 ? '...' : '') : null);
    });
  } catch(e) {
    console.log('Hata (log sorgusu):', e.message);
  }
}

main().catch(err => {
  console.error('HATA:', err.message);
  process.exit(1);
});
