#!/usr/bin/env pwsh
# Senaryo A ve B webhook gonderimi - log stream ile birlikte

$SECRET = 'ee7f3ad0a5e469c5fccae35076767a5e96ec33f08d9a7e80ea4c982062d9b70d'
$URL = 'https://hotelgen-v2.vercel.app/api/webhooks/telegram/green-park-otel-demo'
$OZGUR_TG_ID = 758605940

Write-Host "3 saniye bekleniyor log stream'in hazir olmasi icin..."
Start-Sleep -Seconds 3

# SENARYO A: Dogrulanmamis kullanici
Write-Host "=== SENARYO A GONDERILIYOR (9999001) ==="
$tsA = [int][DateTimeOffset]::UtcNow.ToUnixTimeSeconds()
$bodyA = "{`"update_id`":600001,`"message`":{`"message_id`":401,`"from`":{`"id`":9999001,`"is_bot`":false,`"first_name`":`"TestA`",`"language_code`":`"tr`"},`"chat`":{`"id`":9999001,`"type`":`"private`"},`"date`":$tsA,`"text`":`"yakinda eczane var mi`"}}"
$rA = Invoke-RestMethod -Uri $URL -Method POST -ContentType 'application/json' -Headers @{ 'x-telegram-bot-api-secret-token' = $SECRET } -Body $bodyA
Write-Host "A yaniti: $($rA | ConvertTo-Json -Compress)"

Write-Host "15 saniye bekleniyor (A islenmesi icin)..."
Start-Sleep -Seconds 15

# SENARYO B: Ozgur
Write-Host "=== SENARYO B GONDERILIYOR (Ozgur, 758605940) ==="
$tsB = [int][DateTimeOffset]::UtcNow.ToUnixTimeSeconds()
$bodyB = "{`"update_id`":600010,`"message`":{`"message_id`":410,`"from`":{`"id`":$OZGUR_TG_ID,`"is_bot`":false,`"first_name`":`"Ozgur`",`"language_code`":`"tr`"},`"chat`":{`"id`":$OZGUR_TG_ID,`"type`":`"private`"},`"date`":$tsB,`"text`":`"yakinda eczane var mi`"}}"
$rB = Invoke-RestMethod -Uri $URL -Method POST -ContentType 'application/json' -Headers @{ 'x-telegram-bot-api-secret-token' = $SECRET } -Body $bodyB
Write-Host "B yaniti: $($rB | ConvertTo-Json -Compress)"

Write-Host "Tum mesajlar gonderildi. Log stream'de skipForward ve verification-gate satirlarini ara."
