// scripts/run-bootstrap.mjs
// Demo Hotel için exec_sql bootstrap + baseline seed çalıştırır.
// Supabase-js WebSocket sorununu bypass etmek için raw fetch kullanır.

import { readFileSync } from 'fs';
import { resolve, dirname } from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const DEMO_URL = 'https://rvsyvegfeywzqbqljlij.supabase.co';
const DEMO_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJ2c3l2ZWdmZXl3enFicWxqbGlqIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc3Nzk3MzQ2OCwiZXhwIjoyMDkzNTQ5NDY4fQ.T1NtIugkuxcX0sLcw3LVDavJHLhdXzjwR4FO2oDiEio';

const HEADERS = {
  'Content-Type': 'application/json',
  'apikey': DEMO_KEY,
  'Authorization': `Bearer ${DEMO_KEY}`,
};

// Supabase REST: RPC çağrısı
async function rpc(funcName, params = {}) {
  const res = await fetch(`${DEMO_URL}/rest/v1/rpc/${funcName}`, {
    method: 'POST',
    headers: HEADERS,
    body: JSON.stringify(params),
  });
  const text = await res.text();
  let data = null;
  try { data = JSON.parse(text); } catch { data = text; }
  return { status: res.status, ok: res.ok, data };
}

// Supabase REST: SELECT
async function select(table, query = '') {
  const res = await fetch(`${DEMO_URL}/rest/v1/${table}?${query}&apikey=${DEMO_KEY}`, {
    headers: HEADERS,
  });
  const text = await res.text();
  let data = null;
  try { data = JSON.parse(text); } catch { data = text; }
  return { status: res.status, ok: res.ok, data };
}

// Supabase REST: INSERT (upsert)
async function upsert(table, rows) {
  const res = await fetch(`${DEMO_URL}/rest/v1/${table}`, {
    method: 'POST',
    headers: {
      ...HEADERS,
      'Prefer': 'resolution=ignore-duplicates,return=minimal',
    },
    body: JSON.stringify(rows),
  });
  const text = await res.text();
  let data = null;
  try { data = JSON.parse(text); } catch { data = text; }
  return { status: res.status, ok: res.ok, data };
}

async function main() {
  console.log('=== Demo Hotel Bootstrap + Baseline Seed ===\n');

  // ─────────────────────────────────────────────────────────
  // ADIM 1: exec_sql var mı?
  // ─────────────────────────────────────────────────────────
  console.log('[1/4] exec_sql RPC test ediliyor...');
  const testResult = await rpc('exec_sql', { sql: 'SELECT 1' });

  let execSqlStatus;
  if (testResult.ok || testResult.status === 200) {
    console.log('✅ exec_sql zaten mevcut!');
    execSqlStatus = 'already_exists';
  } else {
    console.log(`❌ exec_sql yok (HTTP ${testResult.status}): ${JSON.stringify(testResult.data)}`);
    execSqlStatus = 'missing';

    const bootstrapPath = resolve(__dirname, '..', 'migrations', 'tenant', '000_bootstrap.sql');
    const sql = readFileSync(bootstrapPath, 'utf-8');
    console.log('\n📋 Lütfen aşağıdaki SQL\'i Supabase SQL Editor\'de çalıştırın:');
    console.log(`   https://supabase.com/dashboard/project/rvsyvegfeywzqbqljlij/sql/new\n`);
    console.log('─'.repeat(70));
    console.log(sql);
    console.log('─'.repeat(70));
    console.log('\nSonra bu scripti tekrar çalıştırın.');
  }

  // ─────────────────────────────────────────────────────────
  // ADIM 2: schema_migrations tablosu var mı?
  // ─────────────────────────────────────────────────────────
  console.log('\n[2/4] schema_migrations tablosu kontrol ediliyor...');
  const tableCheck = await select('schema_migrations', 'select=version&limit=1');

  let tableMissing = false;
  if (tableCheck.status === 404 || (tableCheck.data && tableCheck.data.code === '42P01')) {
    console.log('⚠️ schema_migrations tablosu yok, oluşturulacak...');
    tableMissing = true;
  } else if (!tableCheck.ok) {
    console.log(`⚠️ Tablo kontrol hatası: ${JSON.stringify(tableCheck.data)}`);
    tableMissing = true;
  } else {
    console.log('✅ schema_migrations tablosu mevcut.');
  }

  if (tableMissing && execSqlStatus === 'already_exists') {
    const createTableSql = `
CREATE TABLE IF NOT EXISTS schema_migrations (
  version       TEXT PRIMARY KEY,
  name          TEXT NOT NULL,
  applied_at    TIMESTAMPTZ DEFAULT NOW(),
  applied_by    TEXT,
  success       BOOLEAN DEFAULT TRUE,
  error_message TEXT,
  duration_ms   INTEGER,
  sql_hash      TEXT
)`.trim();
    const createResult = await rpc('exec_sql', { sql: createTableSql });
    if (createResult.ok) {
      console.log('✅ schema_migrations tablosu oluşturuldu.');
    } else {
      console.log(`❌ Tablo oluşturulamadı: ${JSON.stringify(createResult.data)}`);
    }
  }

  // ─────────────────────────────────────────────────────────
  // ADIM 3: Baseline seed (001-006)
  // ─────────────────────────────────────────────────────────
  console.log('\n[3/4] Baseline seed (001-006) ekleniyor...');

  const baseline = [
    { version: '001', name: 'initial_schema',          applied_by: 'baseline-seed', success: true, duration_ms: 0 },
    { version: '002', name: 'perplexity',               applied_by: 'baseline-seed', success: true, duration_ms: 0 },
    { version: '003', name: 'sla_events',               applied_by: 'baseline-seed', success: true, duration_ms: 0 },
    { version: '004', name: 'module15_iban',            applied_by: 'baseline-seed', success: true, duration_ms: 0 },
    { version: '005', name: 'module17_inhouse',         applied_by: 'baseline-seed', success: true, duration_ms: 0 },
    { version: '006', name: 'module17_notifications',   applied_by: 'baseline-seed', success: true, duration_ms: 0 },
  ];

  const seedResult = await upsert('schema_migrations', baseline);
  if (seedResult.ok || seedResult.status === 201 || seedResult.status === 200) {
    console.log(`✅ Baseline seed tamamlandı. ${baseline.length} kayıt eklendi (veya zaten vardı).`);
  } else {
    console.log(`❌ Seed hatası (HTTP ${seedResult.status}): ${JSON.stringify(seedResult.data)}`);

    // Hata mesajını analiz et
    if (JSON.stringify(seedResult.data).includes('does not exist')) {
      console.log('\n⚠️ schema_migrations tablosu henüz yok.');
      console.log('Önce exec_sql bootstrap SQL\'ini çalıştırın, sonra tekrar deneyin.');
    }
  }

  // ─────────────────────────────────────────────────────────
  // ADIM 4: Doğrulama
  // ─────────────────────────────────────────────────────────
  console.log('\n[4/4] Durum doğrulanıyor...');
  const statusCheck = await select('schema_migrations', 'select=version,name,applied_by,success&order=version.asc');

  if (statusCheck.ok && Array.isArray(statusCheck.data)) {
    const rows = statusCheck.data;
    const applied = rows.filter(r => r.success).length;
    console.log(`\n📊 Migration Durumu:`);
    console.log(`   Toplam kayıt: ${rows.length}`);
    console.log(`   Başarılı: ${applied}`);
    console.log(`\n   Versiyon tablosu:`);
    for (const row of rows) {
      const icon = row.success ? '✅' : '❌';
      console.log(`   ${icon} ${row.version} — ${row.name} (${row.applied_by})`);
    }

    // Pending hesapla (001-006)
    const allVersions = ['001','002','003','004','005','006'];
    const appliedSet = new Set(rows.filter(r => r.success).map(r => r.version));
    const pending = allVersions.filter(v => !appliedSet.has(v));
    console.log(`\n   Bekleyen: ${pending.length > 0 ? pending.join(', ') : 'YOK — güncel!'}`);
    if (pending.length === 0) {
      console.log('\n🎉 Demo Hotel veritabanı güncel! 6/6 migration uygulanmış.');
    }
  } else {
    console.log(`❌ Durum sorgulanamadı: ${JSON.stringify(statusCheck.data)}`);
  }

  console.log('\n=== Tamamlandı ===');
  console.log(`exec_sql: ${execSqlStatus}`);
}

main().catch(err => {
  console.error('Beklenmedik hata:', err);
  process.exit(1);
});
