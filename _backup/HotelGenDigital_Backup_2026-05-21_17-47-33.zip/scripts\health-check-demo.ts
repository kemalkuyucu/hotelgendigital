/**
 * health-check-demo.ts — GEÇİCİ TANI SCRIPT'İ
 * Demo Hotel DB durumunu kontrol eder.
 * Bu dosya .gitignore'd edilmiştir (scripts/ klasörü).
 *
 * Çalıştır: npx tsx scripts/health-check-demo.ts
 */

import { createClient } from '@supabase/supabase-js'
import ws from 'ws'
import * as dotenv from 'dotenv'
import * as path from 'path'
import * as fs from 'fs'

// .env.local dosyasını yükle
const envPath = path.resolve(process.cwd(), '.env.local')
if (fs.existsSync(envPath)) {
  dotenv.config({ path: envPath })
} else {
  dotenv.config()
}

const DEMO_URL = process.env.DEMO_HOTEL_SUPABASE_URL
const DEMO_KEY = process.env.DEMO_HOTEL_SUPABASE_SERVICE_ROLE_KEY
const CHAT_ID = 758605940

if (!DEMO_URL || !DEMO_KEY) {
  console.error('❌ DEMO_HOTEL_SUPABASE_URL veya DEMO_HOTEL_SUPABASE_SERVICE_ROLE_KEY eksik!')
  process.exit(1)
}

// Node.js 20 lacks native WebSocket; supply 'ws' package as transport
const supa = createClient(DEMO_URL, DEMO_KEY, {
  auth: { persistSession: false, autoRefreshToken: false },
  realtime: { transport: ws },
})

function hr() {
  console.log('─'.repeat(70))
}

async function main() {
  console.log('\n╔══════════════════════════════════════════════════════════════════════╗')
  console.log('║         DEMO HOTEL DB SAĞLIK RAPORU — health-check-demo.ts          ║')
  console.log('╚══════════════════════════════════════════════════════════════════════╝\n')

  // ─── 1) schema_migrations ─────────────────────────────────────────────────
  hr()
  console.log('1) schema_migrations — Tüm kayıtlar:')
  hr()
  const { data: migrations, error: migErr } = await supa
    .from('schema_migrations')
    .select('*')
    .order('version', { ascending: true })

  if (migErr) {
    console.error('  ❌ Hata:', migErr.message)
  } else if (!migrations || migrations.length === 0) {
    console.log('  ⚠️  schema_migrations tablosu boş veya yok.')
  } else {
    console.log(`  Toplam kayıt: ${migrations.length}`)
    for (const m of migrations) {
      const status = m.success ? '✅' : '❌'
      console.log(
        `  ${status}  v${m.version}  ${m.name ?? ''}  applied_at=${m.applied_at ?? 'NULL'}  applied_by=${m.applied_by ?? 'NULL'}  success=${m.success}`
      )
    }
  }

  // ─── 2) conversations kolonları (multi_match_*) ───────────────────────────
  hr()
  console.log('2) information_schema — conversations.multi_match_* kolonları:')
  hr()
  const { data: cols, error: colErr } = await supa
    .from('information_schema.columns' as string)
    .select('column_name, data_type, column_default')
    .eq('table_name', 'conversations')
    .ilike('column_name', 'multi_match%')

  if (colErr) {
    // Supabase genellikle information_schema'ya PostgREST ile erişim kısıtlar.
    // Bu durumda alternatif yol: doğrudan kolon listesi çekme
    console.log('  ⚠️  information_schema erişimi kısıtlı (normal). Alternatif sorgu deneniyor...')

    // conversations tablosundan tek satır çekerek kolonları kontrol edelim
    const { data: testRow, error: testErr } = await supa
      .from('conversations')
      .select('multi_match_pending_room, multi_match_attempts, multi_match_notified')
      .limit(1)
    if (testErr) {
      console.log(`  ❌ multi_match_* kolonları YOK veya erişilemiyor: ${testErr.message}`)
    } else {
      console.log('  ✅ multi_match_pending_room   → MEVCUT')
      console.log('  ✅ multi_match_attempts       → MEVCUT')
      console.log('  ✅ multi_match_notified       → MEVCUT')
      console.log('  Sample değerler (ilk satır):', testRow?.[0] ?? 'Hiç kayıt yok')
    }
  } else {
    if (!cols || cols.length === 0) {
      console.log('  ❌ multi_match_* kolonları bulunamadı (008 migration uygulanmamış?)')
    } else {
      for (const c of cols) {
        console.log(`  ✅  ${c.column_name}  type=${c.data_type}  default=${c.column_default ?? 'NULL'}`)
      }
    }
  }

  // ─── 3) conversations — chat_id=758605940 ────────────────────────────────
  hr()
  console.log(`3) conversations — chat_id=${CHAT_ID} (Son 5 kayıt):`)
  hr()
  const { data: convs, error: convErr } = await supa
    .from('conversations')
    .select(
      'id, status, verification_state, multi_match_pending_room, multi_match_attempts, multi_match_notified, inhouse_match_guest_id, verified_inhouse_guest_id, created_at, last_message_at'
    )
    .eq('telegram_chat_id', CHAT_ID)
    .order('created_at', { ascending: false })
    .limit(5)

  if (convErr) {
    // 'status' veya 'verification_state' kolonu yoksa tekrar dene
    console.log(`  ⚠️  İlk sorgu hatası: ${convErr.message}`)
    console.log('  Basit sorgu deneniyor...')
    const { data: convs2, error: convErr2 } = await supa
      .from('conversations')
      .select('id, multi_match_pending_room, multi_match_attempts, multi_match_notified, inhouse_match_guest_id, created_at, last_message_at')
      .eq('telegram_chat_id', CHAT_ID)
      .order('created_at', { ascending: false })
      .limit(5)
    if (convErr2) {
      console.error('  ❌ Hata:', convErr2.message)
    } else {
      console.log(`  Bulunan kayıt sayısı: ${convs2?.length ?? 0}`)
      for (const c of (convs2 ?? [])) {
        console.log('  ---')
        console.log('  id                    :', c.id)
        console.log('  inhouse_match_guest_id:', c.inhouse_match_guest_id ?? 'NULL ← Henüz eşleşmemiş')
        console.log('  multi_match_pending_room  :', c.multi_match_pending_room ?? 'NULL')
        console.log('  multi_match_attempts      :', c.multi_match_attempts ?? 0)
        console.log('  multi_match_notified      :', c.multi_match_notified ?? false)
        console.log('  created_at                :', c.created_at)
        console.log('  last_message_at           :', c.last_message_at)
      }
    }
  } else {
    console.log(`  Bulunan kayıt sayısı: ${convs?.length ?? 0}`)
    for (const c of (convs ?? [])) {
      console.log('  ---')
      console.log('  id                        :', c.id)
      console.log('  status                    :', c.status ?? 'KOLON YOK')
      console.log('  verification_state        :', (c as Record<string, unknown>).verification_state ?? 'KOLON YOK')
      console.log('  inhouse_match_guest_id    :', c.inhouse_match_guest_id ?? 'NULL ← Henüz eşleşmemiş')
      console.log('  verified_inhouse_guest_id :', c.verified_inhouse_guest_id ?? 'NULL')
      console.log('  multi_match_pending_room  :', c.multi_match_pending_room ?? 'NULL')
      console.log('  multi_match_attempts      :', c.multi_match_attempts ?? 0)
      console.log('  multi_match_notified      :', c.multi_match_notified ?? false)
      console.log('  created_at                :', c.created_at)
      console.log('  last_message_at           :', c.last_message_at)
    }
  }

  // ─── 4) pending_guest_matches — chat_id=758605940 ─────────────────────────
  hr()
  console.log(`4) pending_guest_matches — telegram_chat_id=${CHAT_ID} (Son 5):`)
  hr()
  const { data: pgm, error: pgmErr } = await supa
    .from('pending_guest_matches')
    .select('*')
    .eq('telegram_chat_id', CHAT_ID)
    .order('created_at', { ascending: false })
    .limit(5)

  if (pgmErr) {
    // telegram_chat_id kolonu yoksa telegram_id ile deneyelim
    console.log(`  ⚠️  telegram_chat_id kolonu yok, telegram_id ile deneniyor: ${pgmErr.message}`)
    const { data: pgm2, error: pgmErr2 } = await supa
      .from('pending_guest_matches')
      .select('*')
      .eq('telegram_id', CHAT_ID)
      .order('created_at', { ascending: false })
      .limit(5)
    if (pgmErr2) {
      console.error('  ❌ Hata:', pgmErr2.message)
    } else {
      console.log(`  Bulunan kayıt sayısı: ${pgm2?.length ?? 0}`)
      console.log('  Kayıtlar:', JSON.stringify(pgm2, null, 2))
    }
  } else {
    console.log(`  Bulunan kayıt sayısı: ${pgm?.length ?? 0}`)
    for (const m of (pgm ?? [])) {
      console.log('  ---')
      console.log('  ', JSON.stringify(m, null, 2))
    }
  }

  // ─── 5) inhouse_guests_v2 — aktif sayı ────────────────────────────────────
  hr()
  console.log('5) inhouse_guests_v2 — Aktif misafir sayısı:')
  hr()
  // status='active' kullanan sorgu (is_active kolonu yok)
  const { count: activeCount, error: countErr } = await supa
    .from('inhouse_guests_v2')
    .select('id', { count: 'exact', head: true })
    .eq('status', 'active')

  if (countErr) {
    // Belki status kolonu da yoksa tüm satırları say
    console.log(`  ⚠️  status kolonu da yok: ${countErr.message}`)
    const { count: fallbackCount, error: fallErr } = await supa
      .from('inhouse_guests_v2')
      .select('id', { count: 'exact', head: true })
    if (fallErr) {
      console.error('  ❌ Hata:', fallErr.message)
    } else {
      console.log(`  Toplam misafir sayısı (status filtresi olmadan): ${fallbackCount ?? 0}`)
    }
  } else {
    console.log(`  Aktif misafir sayısı (status='active'): ${activeCount ?? 0}`)
  }

  // status='active' filtresiyle sorgula (is_active kolonu bulunmuyor)
  const { data: room101, error: roomErr } = await supa
    .from('inhouse_guests_v2')
    .select('id, room_number, guest_name, status, telegram_id')
    .eq('room_number', '101')
    .eq('status', 'active')

  if (roomErr) {
    // Belki status da yoksa filtresiz dene
    console.log(`  ⚠️  status kolonu yok, filtresiz sorgulaniyor: ${roomErr.message}`)
    const { data: room101b, error: roomErr2 } = await supa
      .from('inhouse_guests_v2')
      .select('id, room_number, guest_name, telegram_id')
      .eq('room_number', '101')
    if (roomErr2) {
      console.error('  ❌ Hata:', roomErr2.message)
    } else if (!room101b || room101b.length === 0) {
      console.log("  ⚠️  Oda 101'de HİÇ misafir kaydı yok")
    } else {
      console.log(`  Bulunan kayıt sayısı: ${room101b.length}`)
      for (const g of room101b) {
        console.log('  ---')
        console.log('  id          :', g.id)
        console.log('  room_number :', g.room_number)
        console.log('  guest_name  :', g.guest_name)
        console.log('  telegram_id :', g.telegram_id ?? 'NULL (eşleştirilmemiş)')
      }
    }
  } else if (!room101 || room101.length === 0) {
    console.log("  ⚠️  Oda 101'de aktif misafir YOK (status='active')")
    // Tüm kayıtlara bak
    const { data: room101all } = await supa
      .from('inhouse_guests_v2')
      .select('id, room_number, guest_name, status, telegram_id')
      .eq('room_number', '101')
    if (room101all && room101all.length > 0) {
      console.log(`  (Statüsü active olmayan kayıtlar mevcut: ${room101all.length})`)
      for (const g of room101all) {
        console.log(`  ❌  id=${g.id} guest_name=${g.guest_name} status=${g.status} telegram_id=${g.telegram_id ?? 'NULL'}`)
      }
    } else {
      console.log("  (Oda 101 için hiç kayıt bulunamadı)")
    }
  } else {
    console.log(`  Bulunan kayıt sayısı: ${room101.length}`)
    for (const g of room101) {
      console.log('  ---')
      console.log('  id          :', g.id)
      console.log('  room_number :', g.room_number)
      console.log('  guest_name  :', g.guest_name)
      console.log('  status      :', g.status ?? 'KOLON YOK')
      console.log('  telegram_id :', g.telegram_id ?? 'NULL (eşleştirilmemiş)')
    }
  }

  hr()
  console.log('\n✅ Health-check tamamlandı.')
  hr()
}

main().catch((err) => {
  console.error('❌ Health-check kritik hata:', err)
  process.exit(1)
})
