/**
 * Modul 17b — In-House List API (genisletilmis)
 * GET /api/hotel-admin/[slug]/inhouse/list
 *
 * Query parametreleri:
 *   view:   "filter" (default) | "all"
 *   filter: "today" | "tomorrow" | "range"  (sadece view=filter ise)
 *   start:  YYYY-MM-DD (sadece filter=range ise)
 *   end:    YYYY-MM-DD (sadece filter=range ise)
 *
 * Her satira last_notification eklenir:
 *   { notification_date, status, sent_at } | null
 *
 * Yetki: hotel_owner veya front_office_manager
 * Siralama: room_number ASC
 */

import { NextRequest, NextResponse } from 'next/server'
import { getHotelAdminFromCookie } from '@/lib/hotel-admin/auth'
import { resolveTenantBySlug } from '@/lib/hotel-admin/tenant'
import { getTurkeyToday, getTurkeyTomorrow } from '@/lib/date/turkeyTime'

const ALLOWED_ROLES = ['hotel_owner', 'front_office_manager']

// ─── Last notification lookup ─────────────────────────────────────────────────

interface LastNotification {
  notification_date: string
  status: string
  sent_at: string | null
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
async function fetchLastNotifications(
  supabase: any,
  guestIds: string[],
): Promise<Map<string, LastNotification | null>> {
  const map = new Map<string, LastNotification | null>()
  if (guestIds.length === 0) return map

  // Initialize all as null
  for (const id of guestIds) {
    map.set(id, null)
  }

  const { data, error } = await supabase
    .from('late_checkout_notifications')
    .select('inhouse_guest_id, notification_date, status, sent_at')
    .in('inhouse_guest_id', guestIds)
    .eq('status', 'sent')
    .order('sent_at', { ascending: false })

  if (error) {
    console.error('[inhouse/list] last_notification fetch error:', error.message)
    return map
  }

  // Keep only the most recent per guest (data is sorted DESC by sent_at)
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  for (const row of (data ?? []) as any[]) {
    if (map.get(row.inhouse_guest_id) === null) {
      map.set(row.inhouse_guest_id, {
        notification_date: row.notification_date,
        status: row.status,
        sent_at: row.sent_at,
      })
    }
  }

  return map
}

// ─── Route handler ────────────────────────────────────────────────────────────

export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ slug: string }> },
): Promise<NextResponse> {
  // ── Auth ──────────────────────────────────────────────────────────────────
  const admin = await getHotelAdminFromCookie()
  if (!admin) {
    return NextResponse.json({ error: 'Yetkisiz erişim.' }, { status: 401 })
  }
  if (!ALLOWED_ROLES.includes(admin.role)) {
    return NextResponse.json(
      { error: 'Bu sayfaya erişim yetkiniz yok.' },
      { status: 403 },
    )
  }

  const { slug } = await params
  if (slug !== admin.hotel_slug) {
    return NextResponse.json({ error: 'Yetkisiz erişim.' }, { status: 403 })
  }

  // ── Query parametreleri ────────────────────────────────────────────────────
  const { searchParams } = req.nextUrl
  const view = searchParams.get('view') ?? 'filter'   // "filter" | "all"
  const filter = searchParams.get('filter') ?? 'tomorrow'
  const startParam = searchParams.get('start')
  const endParam = searchParams.get('end')

  try {
    const tenant = await resolveTenantBySlug(slug)
    const { hotelSupabase: supabase } = tenant

    // ── view=all: butun aktif misafirler, tarih filtresi yok ──────────────
    if (view === 'all') {
      console.log(`[inhouse/list] slug=${slug} view=all`)

      const { data: allData, error: allError } = await supabase
        .from('inhouse_guests_v2')
        .select(
          'id, room_number, agency, guest_name, guest_count, check_in_date, check_out_date, telegram_id, whatsapp_id, status',
        )
        .eq('status', 'active')
        .order('room_number', { ascending: true })

      if (allError) {
        console.error('[inhouse/list] view=all DB error:', allError.message)
        return NextResponse.json(
          { error: 'Misafir listesi alınamadı: ' + allError.message },
          { status: 500 },
        )
      }

      const allGuests = allData ?? []
      const notifMap = await fetchLastNotifications(
        supabase,
        allGuests.map((g) => g.id),
      )

      const guestsWithNotif = allGuests.map((g) => ({
        ...g,
        last_notification: notifMap.get(g.id) ?? null,
      }))

      console.log(`[inhouse/list] view=all found ${guestsWithNotif.length} guests`)

      return NextResponse.json({
        guests: guestsWithNotif,
        meta: {
          view: 'all',
          count: guestsWithNotif.length,
        },
      })
    }

    // ── view=filter: tarih filtreli sorgu (mevcut davranis) ──────────────
    let dateStart: string
    let dateEnd: string

    if (filter === 'today') {
      dateStart = getTurkeyToday()
      dateEnd = dateStart
    } else if (filter === 'tomorrow') {
      dateStart = getTurkeyTomorrow()
      dateEnd = dateStart
    } else if (filter === 'range') {
      if (!startParam || !endParam) {
        return NextResponse.json(
          { error: 'range filtresi icin start ve end parametreleri zorunludur.' },
          { status: 400 },
        )
      }
      if (!/^\d{4}-\d{2}-\d{2}$/.test(startParam) || !/^\d{4}-\d{2}-\d{2}$/.test(endParam)) {
        return NextResponse.json(
          { error: 'Tarih formati YYYY-MM-DD olmalidir.' },
          { status: 400 },
        )
      }
      dateStart = startParam
      dateEnd = endParam
    } else {
      return NextResponse.json(
        { error: 'Gecersiz filter degeri. today | tomorrow | range bekleniyor.' },
        { status: 400 },
      )
    }

    console.log(`[inhouse/list] slug=${slug} view=filter filter=${filter} dateStart=${dateStart} dateEnd=${dateEnd}`)

    let query = supabase
      .from('inhouse_guests_v2')
      .select(
        'id, room_number, agency, guest_name, guest_count, check_in_date, check_out_date, telegram_id, whatsapp_id, status',
      )
      .eq('status', 'active')
      .order('room_number', { ascending: true })

    if (dateStart === dateEnd) {
      query = query.eq('check_out_date', dateStart)
    } else {
      query = query.gte('check_out_date', dateStart).lte('check_out_date', dateEnd)
    }

    const { data, error } = await query

    if (error) {
      console.error('[inhouse/list] DB error:', error.message)
      return NextResponse.json(
        { error: 'Misafir listesi alınamadı: ' + error.message },
        { status: 500 },
      )
    }

    const guests = data ?? []
    const notifMap = await fetchLastNotifications(
      supabase,
      guests.map((g) => g.id),
    )

    const guestsWithNotif = guests.map((g) => ({
      ...g,
      last_notification: notifMap.get(g.id) ?? null,
    }))

    console.log(`[inhouse/list] Found ${guestsWithNotif.length} guests for date range ${dateStart}..${dateEnd}`)

    return NextResponse.json({
      guests: guestsWithNotif,
      meta: {
        view: 'filter',
        filter,
        dateStart,
        dateEnd,
        count: guestsWithNotif.length,
      },
    })
  } catch (err) {
    const msg = err instanceof Error ? err.message : 'Sunucu hatası.'
    console.error('[inhouse/list] Fatal:', msg)
    return NextResponse.json({ error: msg }, { status: 500 })
  }
}
