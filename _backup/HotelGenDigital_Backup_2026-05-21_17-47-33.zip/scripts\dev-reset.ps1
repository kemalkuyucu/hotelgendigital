# HotelGen v2 - Dev Server Temiz Reset
# Kullanim: .\scripts\dev-reset.ps1

Write-Host "[1/4] Node process'leri durduruluyor..." -ForegroundColor Yellow
Stop-Process -Name node -Force -ErrorAction SilentlyContinue
Start-Sleep -Seconds 1

Write-Host "[2/4] .next cache temizleniyor..." -ForegroundColor Yellow
if (Test-Path .next) {
    Remove-Item -Recurse -Force .next -ErrorAction SilentlyContinue
}

Write-Host "[3/4] Port 3000 ve 3001 kontrol ediliyor..." -ForegroundColor Yellow
$ports = @(3000, 3001)
foreach ($port in $ports) {
    $conn = Get-NetTCPConnection -LocalPort $port -State Listen -ErrorAction SilentlyContinue
    if ($conn) {
        Write-Host "  Port $port'da hala process var (PID: $($conn.OwningProcess)), kapatiliyor..."
        Stop-Process -Id $conn.OwningProcess -Force -ErrorAction SilentlyContinue
    }
}
Start-Sleep -Seconds 1

Write-Host "[4/4] Dev server baslatiliyor..." -ForegroundColor Green
Write-Host ""
Write-Host "Tarayicidan acmak icin: http://localhost:3000" -ForegroundColor Cyan
Write-Host ""
npm run dev
