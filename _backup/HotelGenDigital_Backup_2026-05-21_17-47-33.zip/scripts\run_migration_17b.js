/**
 * run_migration_17b.js
 * Executes the late_checkout_notifications migration on Demo Hotel Supabase
 * via Supabase Management API (SQL endpoint).
 *
 * Usage: node scripts/run_migration_17b.js
 */

const DEMO_HOTEL_URL = 'https://rvsyvegfeywzqbqljlij.supabase.co';
const SERVICE_KEY =
  'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJ2c3l2ZWdmZXl3enFicWxqbGlqIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc3Nzk3MzQ2OCwiZXhwIjoyMDkzNTQ5NDY4fQ.T1NtIugkuxcX0sLcw3LVDavJHLhdXzjwR4FO2oDiEio';

// Ref ID extracted from the URL: rvsyvegfeywzqbqljlij
const PROJECT_REF = 'rvsyvegfeywzqbqljlij';

const SQL = `
CREATE TABLE IF NOT EXISTS late_checkout_notifications (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  inhouse_guest_id UUID NOT NULL REFERENCES inhouse_guests_v2(id)
    ON DELETE CASCADE,
  notification_date DATE NOT NULL,
  channel TEXT NOT NULL CHECK (channel IN ('telegram', 'whatsapp', 'manual')),
  message_content TEXT,
  status TEXT NOT NULL DEFAULT 'pending'
    CHECK (status IN ('pending', 'sent', 'failed')),
  error_message TEXT,
  sent_at TIMESTAMPTZ,
  sent_by_user_id UUID,
  sent_by_username TEXT,
  created_at TIMESTAMPTZ DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_late_notif_guest
  ON late_checkout_notifications(inhouse_guest_id);

CREATE INDEX IF NOT EXISTS idx_late_notif_date
  ON late_checkout_notifications(notification_date);

CREATE INDEX IF NOT EXISTS idx_late_notif_status
  ON late_checkout_notifications(status);

SELECT 'migration_done' as result;
`;

async function runMigration() {
  console.log('[migration] Connecting to Demo Hotel Supabase...');

  // Use the Supabase REST /sql endpoint (postgres-meta compatible)
  const endpoint = `${DEMO_HOTEL_URL}/rest/v1/rpc/query`;

  // Try pg_query RPC first (if custom function exists), else use SQL API
  // Supabase exposes a SQL API via Management API, but for direct DB we use PostgREST
  // The safest approach: use the pg query API via Management API
  const mgmtUrl = `https://api.supabase.com/v1/projects/${PROJECT_REF}/database/query`;

  // We don't have a management API token here; use the service role key approach
  // with PostgREST RPC if available, or fall back to individual table operations.

  // Try: POST /rest/v1/rpc/exec (custom function, may not exist)
  // Alternative: directly check by creating a small test via table operations
  
  // Use PostgREST SQL via pg_graphql or direct connection
  // The most reliable way is to check if table exists via select
  
  const checkRes = await fetch(`${DEMO_HOTEL_URL}/rest/v1/late_checkout_notifications?select=id&limit=1`, {
    headers: {
      apikey: SERVICE_KEY,
      Authorization: `Bearer ${SERVICE_KEY}`,
    },
  });

  if (checkRes.status === 200) {
    console.log('[migration] Table late_checkout_notifications already exists! Skipping creation.');
    const data = await checkRes.json();
    console.log('[migration] Current row count query returned:', data.length, 'rows (limit 1)');
    return;
  }

  console.log('[migration] Table does not exist (status:', checkRes.status, '). Need to create via SQL.');
  console.log('[migration] Response:', await checkRes.text());
  console.log('');
  console.log('[migration] ACTION REQUIRED: Please run the following SQL in Demo Hotel Supabase SQL Editor:');
  console.log('URL: https://supabase.com/dashboard/project/rvsyvegfeywzqbqljlij/sql/new');
  console.log('');
  console.log(SQL);
}

runMigration().catch((err) => {
  console.error('[migration] Fatal error:', err.message);
  process.exit(1);
});
