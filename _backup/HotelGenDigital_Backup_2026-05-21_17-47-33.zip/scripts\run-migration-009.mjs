import { readFileSync } from 'fs';

const env = readFileSync('.env.local', 'utf8');
const getVal = (k) => {
  const lines = env.split('\n');
  for (const l of lines) {
    const trimmed = l.trim();
    if (trimmed.startsWith(k + '=')) {
      return trimmed.slice(k.length + 1).replace(/^["']|["']$/g, '').trim();
    }
  }
  return null;
};

const url = getVal('CENTRAL_SUPABASE_URL');
const key = getVal('CENTRAL_SUPABASE_SERVICE_ROLE_KEY');
// Management API key (same as service role or a separate management token)
const mgmtKey = getVal('SUPABASE_ACCESS_TOKEN') || getVal('SUPABASE_MANAGEMENT_TOKEN');

// Extract project ref from URL: https://hrbqqjcgixazzrvvgars.supabase.co
const projectRef = url ? url.replace('https://', '').split('.')[0] : null;

console.log('Project ref:', projectRef);
console.log('Management key found:', !!mgmtKey);

if (!projectRef) {
  console.error('Cannot determine project ref');
  process.exit(1);
}

// Try Supabase Management API v1
// https://api.supabase.com/v1/projects/{ref}/database/query
const queries = [
  'ALTER TABLE hotels ADD COLUMN IF NOT EXISTS deleted_at TIMESTAMPTZ',
  'ALTER TABLE hotels ADD COLUMN IF NOT EXISTS deleted_by TEXT',
  'CREATE INDEX IF NOT EXISTS idx_hotels_deleted_at ON hotels(deleted_at) WHERE deleted_at IS NULL',
];

async function runViaManagementAPI(sql, token) {
  const res = await fetch(`https://api.supabase.com/v1/projects/${projectRef}/database/query`, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ query: sql }),
  });
  return { status: res.status, body: await res.text() };
}

// Alternative: try using the service_role key via pg REST direct SQL
async function runViaServiceRole(sql) {
  // Supabase exposes a sql endpoint when using service_role
  const res = await fetch(`${url}/rest/v1/rpc/exec_sql`, {
    method: 'POST',
    headers: {
      apikey: key,
      Authorization: `Bearer ${key}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ sql }),
  });
  return { status: res.status, body: await res.text() };
}

console.log('\nAttempting migration via Management API...');

if (mgmtKey) {
  for (const sql of queries) {
    const label = sql.substring(0, 55) + '...';
    const result = await runViaManagementAPI(sql, mgmtKey);
    if (result.status === 200 || result.status === 204 || result.status === 201) {
      console.log(`✅ ${label}`);
    } else {
      console.log(`❌ HTTP ${result.status}: ${result.body.substring(0, 150)}`);
      console.log('   → Apply manually via Supabase Dashboard SQL Editor');
    }
  }
} else {
  console.log('No management API token found in .env.local');
  console.log('\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
  console.log('MANUAL STEPS — Supabase Dashboard > SQL Editor:');
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n');
  console.log('-- Run these 3 statements one by one:\n');
  console.log('ALTER TABLE hotels ADD COLUMN IF NOT EXISTS deleted_at TIMESTAMPTZ;\n');
  console.log('ALTER TABLE hotels ADD COLUMN IF NOT EXISTS deleted_by TEXT;\n');
  console.log('CREATE INDEX IF NOT EXISTS idx_hotels_deleted_at ON hotels(deleted_at) WHERE deleted_at IS NULL;\n');
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
  console.log('\nProject URL: https://supabase.com/dashboard/project/' + projectRef + '/editor');
}

// Verify after
const verifyRes = await fetch(`${url}/rest/v1/hotels?select=deleted_at,deleted_by&limit=1`, {
  headers: { apikey: key, Authorization: `Bearer ${key}` },
});
if (verifyRes.ok) {
  console.log('\n✅ VERIFIED: columns exist and are accessible');
} else {
  const msg = await verifyRes.text();
  console.log('\n⚠️  Columns still missing:', msg.substring(0, 150));
}
