# HotelGen v2 - Dev Server Durumu
# Kullanim: .\scripts\dev-status.ps1

Write-Host "=== Dev Server Durumu ===" -ForegroundColor Cyan
Write-Host ""

$nodeProcesses = Get-Process node -ErrorAction SilentlyContinue
if ($nodeProcesses) {
    Write-Host "[Node Process'leri]" -ForegroundColor Yellow
    $nodeProcesses | Format-Table Id, ProcessName, @{Name='RAM (MB)';Expression={[math]::Round($_.WorkingSet64/1MB,1)}} -AutoSize
} else {
    Write-Host "[Node Process'leri] HIC YOK - Dev server kapali" -ForegroundColor Red
}

Write-Host "[Port Kontrolu]" -ForegroundColor Yellow
$ports = @(3000, 3001)
foreach ($port in $ports) {
    $conn = Get-NetTCPConnection -LocalPort $port -State Listen -ErrorAction SilentlyContinue
    if ($conn) {
        Write-Host "  Port ${port}: DINLIYOR (PID: $($conn.OwningProcess))" -ForegroundColor Green
    } else {
        Write-Host "  Port ${port}: BOS" -ForegroundColor Gray
    }
}

Write-Host ""
Write-Host "[HTTP Test]" -ForegroundColor Yellow
foreach ($port in $ports) {
    try {
        $r = Invoke-WebRequest "http://localhost:$port" -UseBasicParsing -TimeoutSec 5 -ErrorAction Stop
        Write-Host "  http://localhost:$port -> CALISIYOR (HTTP $($r.StatusCode))" -ForegroundColor Green
    } catch {
        Write-Host "  http://localhost:$port -> CEVAP YOK" -ForegroundColor Gray
    }
}
