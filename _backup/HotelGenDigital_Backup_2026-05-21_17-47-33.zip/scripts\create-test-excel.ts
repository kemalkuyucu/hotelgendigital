/**
 * Modul 17a — Test Excel Dosyasi Olusturucu
 * Calistirmak icin: npx tsx scripts/create-test-excel.ts
 * Cikti: scripts/test-inhouse.xlsx
 */

import * as XLSX from 'xlsx'
import * as path from 'path'
import * as fs from 'fs'

const data = [
  // Baslik satiri
  ['Oda No', 'Acenta', 'Ad Soyad', 'Kisi', 'Giris', 'Cikis'],
  // Veri satirlari
  ['101', 'Pegasus Tours',   'Ahmet Yilmaz',     '2', '2026-05-18', '2026-05-22'],
  ['203', 'Corendon',        'Marie Dupont',      '1', '2026-05-17', '2026-05-24'],
  ['315', '',                'Ivan Petrov',       '3', '2026-05-16', '2026-05-21'],
  ['422', 'TUI',             'Hans Mueller',      '2', '2026-05-18', '2026-05-25'],
  ['507', 'Neckermann',      'Fatima Al-Hassan',  '4', '2026-05-15', '2026-05-20'],
]

const ws = XLSX.utils.aoa_to_sheet(data)
const wb = XLSX.utils.book_new()
XLSX.utils.book_append_sheet(wb, ws, 'InHouse')

const outPath = path.join(process.cwd(), 'scripts', 'test-inhouse.xlsx')
XLSX.writeFile(wb, outPath)

console.log('Test Excel created:', outPath)
console.log('Columns: Oda No, Acenta, Ad Soyad, Kisi, Giris, Cikis')
console.log('Rows:', data.length - 1, 'guests')
