/**
 * cleanup-pending-matches.ts — GEÇİCİ CLEANUP SCRIPT'İ
 * telegram_id=758605940 için çözülmemiş pending_guest_matches kayıtlarını resolve eder.
 * Bu dosya .gitignore'd (scripts/ klasörü).
 *
 * Çalıştır: npx tsx scripts/cleanup-pending-matches.ts
 */

import { createClient } from '@supabase/supabase-js'
import ws from 'ws'
import * as dotenv from 'dotenv'
import * as path from 'path'
import * as fs from 'fs'

// .env.local dosyasını yükle
const envPath = path.resolve(process.cwd(), '.env.local')
if (fs.existsSync(envPath)) {
  dotenv.config({ path: envPath })
} else {
  dotenv.config()
}

const DEMO_URL = process.env.DEMO_HOTEL_SUPABASE_URL
const DEMO_KEY = process.env.DEMO_HOTEL_SUPABASE_SERVICE_ROLE_KEY
const TELEGRAM_ID = 758605940

if (!DEMO_URL || !DEMO_KEY) {
  console.error('❌ DEMO_HOTEL_SUPABASE_URL veya DEMO_HOTEL_SUPABASE_SERVICE_ROLE_KEY eksik!')
  process.exit(1)
}

const supa = createClient(DEMO_URL, DEMO_KEY, {
  auth: { persistSession: false, autoRefreshToken: false },
  realtime: { transport: ws },
})

async function main() {
  console.log('\n╔══════════════════════════════════════════════════════════════════╗')
  console.log('║        pending_guest_matches CLEANUP — telegram_id=758605940     ║')
  console.log('╚══════════════════════════════════════════════════════════════════╝\n')

  // 1) Kaç tane çözümsüz kayıt var?
  const { count: beforeCount, error: countErr } = await supa
    .from('pending_guest_matches')
    .select('id', { count: 'exact', head: true })
    .eq('telegram_id', TELEGRAM_ID)
    .eq('resolved', false)

  if (countErr) {
    console.error('❌ Sayım hatası:', countErr.message)
    process.exit(1)
  }

  console.log(`  İşlem öncesi — resolved=false kayıt sayısı: ${beforeCount ?? 0}`)

  if ((beforeCount ?? 0) === 0) {
    console.log('  ✅ Zaten temiz, yapılacak işlem yok.')
    return
  }

  // 2) UPDATE
  const { error: updateErr } = await supa
    .from('pending_guest_matches')
    .update({
      resolved: true,
      resolved_at: new Date().toISOString(),
    })
    .eq('telegram_id', TELEGRAM_ID)
    .eq('resolved', false)

  if (updateErr) {
    console.error('❌ UPDATE hatası:', updateErr.message)
    process.exit(1)
  }

  console.log(`  ✅ ${beforeCount} kayıt resolved=true olarak güncellendi.`)

  // 3) Doğrulama — sonradan 0 mı?
  const { count: afterCount, error: afterErr } = await supa
    .from('pending_guest_matches')
    .select('id', { count: 'exact', head: true })
    .eq('telegram_id', TELEGRAM_ID)
    .eq('resolved', false)

  if (afterErr) {
    console.error('❌ Doğrulama sayım hatası:', afterErr.message)
    process.exit(1)
  }

  console.log(`\n  İşlem sonrası — resolved=false kayıt sayısı: ${afterCount ?? 0}`)

  if ((afterCount ?? 0) === 0) {
    console.log('  ✅ DOĞRULAMA BAŞARILI — Tüm kayıtlar temizlendi.')
  } else {
    console.error(`  ❌ DOĞRULAMA BAŞARISIZ — Hâlâ ${afterCount} kayıt çözümsüz!`)
    process.exit(1)
  }

  console.log('\n─────────────────────────────────────────────────────────────────\n')
}

main().catch((err) => {
  console.error('❌ Cleanup kritik hata:', err)
  process.exit(1)
})
